#Requires -Version 5.1
[CmdletBinding(DefaultParameterSetName = 'SingleDate')]
param(
    [Parameter(Mandatory = $true)]
    [string] $ConfigPath,

    [Parameter(ParameterSetName = 'SingleDate')]
    [datetime] $RunDate = (Get-Date),

    [Parameter(Mandatory = $true, ParameterSetName = 'DateRange')]
    [datetime] $StartDate,

    [Parameter(Mandatory = $true, ParameterSetName = 'DateRange')]
    [datetime] $EndDate,

    [switch] $DryRun
)

Set-StrictMode -Version 2.0
$ErrorActionPreference = 'Stop'

$modulePath = Join-Path $PSScriptRoot 'CymulateVectrSync.psd1'
Import-Module -Name $modulePath -Force

$params = @{
    ConfigPath = $ConfigPath
    DryRun     = [bool]$DryRun
}
if ($PSCmdlet.ParameterSetName -eq 'DateRange') {
    $params.StartDate = $StartDate
    $params.EndDate = $EndDate
}
else {
    $params.RunDate = $RunDate
}

Invoke-CymulateVectrSync @params
