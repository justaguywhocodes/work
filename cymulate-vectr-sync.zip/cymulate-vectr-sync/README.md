# Cymulate → VECTR sync

Pinned to **Cymulate OpenAPI 2.0.62**.

## What the API actually is

| Step | Endpoint | Pagination | Envelope |
| --- | --- | --- | --- |
| List launched assessments | `GET /v2/assessments/launched` | `page` **or** `cursor`; response `next` is a URL, `count` is the total, items in `data` | `{ count, data[], next, previous }` |
| Findings for one assessment | `GET /v2/assessments/launched/{id}/findings` | `page`, `limit` (max **100**), `cursor`; response `nextCursor` | `{ count, skip, limit, findings[], nextCursor }` |

There is no `/launched-assessments` path. That is why the Codex script never iterated findings for filtered assessments — it was calling an endpoint that does not exist.

Query `status` values are camelCase (`completed`). Response `status` values are display case (`Completed`). `fromDate` / `toDate` are UTC date-times. Assessments have `startedAt` / `createdAt` / `updatedAt` — **no `endedAt`**. Findings group by `scenarioName` / `testCase` / `testCaseKey`. MITRE lives on `techniques[].mitreID` and `tactics[].mitreID` + `name`. Rate limit is **30 requests / 10 seconds / IP**.

## What this module does

1. Lists launched assessments with `status=completed`, `fromDate`/`toDate`, and follows `next` / `cursor` until `count` is exhausted
2. For **each** date-filtered assessment, pages `.../{id}/findings` on `nextCursor` (limit capped at 100)
3. Groups findings by scenario, keeps SIEM-alert rows, creates one VECTR test case per group
4. Throttles Cymulate calls under the 30/10s cap; `VEC1` prefix on VECTR; JSON that does not unwrap one-element arrays

## Run

```powershell
$env:CYMULATE_API_TOKEN = '<cymulate x-token>'
$env:VECTR_API_KEY = '<vectr api key>'

Import-Module .\CymulateVectrSync.psd1

Invoke-CymulateVectrSync -ConfigPath .\cymulate-vectr.config.json `
    -StartDate 2026-08-01 -EndDate 2026-08-31 -DryRun $true -Verbose
```

US host: `https://api.us-app.cymulate.com`. EU: `https://api.app.cymulate.com`.

Purple Team `GET /v1/purple-team/assessments/findings/{id}` is deprecated in this spec. If you still need it, set `FindingsPathTemplate` to `/v1/purple-team/assessments/findings/{id}`.

Re-runs create duplicate VECTR test cases. Dry-run first.
