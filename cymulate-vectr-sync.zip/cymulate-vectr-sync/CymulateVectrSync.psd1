@{
    RootModule        = 'CymulateVectrSync.psm1'
    ModuleVersion     = '2.0.0'
    GUID              = '7e6c2d91-4a18-4f3b-9d2e-c0a1b2c3d4e5'
    Author            = 'Cymulate VECTR Sync'
    Description       = 'Imports Cymulate launched-assessment findings into VECTR test cases.'
    PowerShellVersion = '5.1'
    FunctionsToExport = @('Invoke-CymulateVectrSync')
    CmdletsToExport   = @()
    VariablesToExport = @()
    AliasesToExport   = @()
}
