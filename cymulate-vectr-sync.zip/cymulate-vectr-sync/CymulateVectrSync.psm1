#Requires -Version 5.1
Set-StrictMode -Version 2.0
$ErrorActionPreference = 'Stop'

# Cymulate → VECTR sync against Cymulate OpenAPI 2.0.62.
# GET /v2/assessments/launched (fromDate/toDate, status=completed, cursor/`next`)
# then GET /v2/assessments/launched/{id}/findings for every match, paging on nextCursor
# until count is exhausted. One VECTR test case per SIEM-alert finding, grouped by
# scenarioName / testCaseKey.

$script:CymulateRequestTimes = New-Object 'System.Collections.Generic.Queue[datetime]'

function Get-PropertyValue {
    param(
        $InputObject,
        [Parameter(Mandatory = $true)] [string] $Name,
        $Default = $null
    )

    if ($null -eq $InputObject) { return $Default }

    if ($InputObject -is [System.Collections.IDictionary]) {
        if ($InputObject.Contains($Name)) {
            $dictValue = $InputObject[$Name]
            if ($null -eq $dictValue) { return $Default }
            return $dictValue
        }
        foreach ($key in $InputObject.Keys) {
            if ([string]$key -ceq $Name) {
                $dictValue = $InputObject[$key]
                if ($null -eq $dictValue) { return $Default }
                return $dictValue
            }
        }
        return $Default
    }

    $property = $InputObject.PSObject.Properties[$Name]
    if ($null -eq $property -or $null -eq $property.Value) { return $Default }
    return $property.Value
}

function Get-FirstPropertyValue {
    param(
        $InputObject,
        [Parameter(Mandatory = $true)] [string[]] $Names,
        $Default = $null
    )

    foreach ($name in $Names) {
        $value = Get-PropertyValue -InputObject $InputObject -Name $name -Default $null
        if ($null -ne $value) { return $value }
    }
    return $Default
}

function Get-RequiredString {
    param(
        [Parameter(Mandatory = $true)] $InputObject,
        [Parameter(Mandatory = $true)] [string] $Name,
        [Parameter(Mandatory = $true)] [string] $Context
    )

    $value = [string](Get-PropertyValue -InputObject $InputObject -Name $Name -Default '')
    if ([string]::IsNullOrWhiteSpace($value)) {
        throw "Missing required configuration value '$Context.$Name'."
    }
    return $value.Trim()
}

function Get-EnvironmentSecret {
    param(
        [Parameter(Mandatory = $true)] $Config,
        [Parameter(Mandatory = $true)] [string] $PropertyName,
        [Parameter(Mandatory = $true)] [string] $Context
    )

    $variableName = Get-RequiredString -InputObject $Config -Name $PropertyName -Context $Context
    $value = [Environment]::GetEnvironmentVariable($variableName)
    if ([string]::IsNullOrWhiteSpace($value)) {
        throw "Environment variable '$variableName', configured by '$Context.$PropertyName', is empty or undefined."
    }
    return $value
}

function ConvertTo-Boolean {
    param($Value, [bool] $Default = $false)
    if ($null -eq $Value) { return $Default }
    if ($Value -is [bool]) { return $Value }
    $text = ([string]$Value).Trim()
    if ([string]::IsNullOrWhiteSpace($text)) { return $Default }
    switch -Regex ($text) {
        '^(?i:true|1|yes|y|on)$' { return $true }
        '^(?i:false|0|no|n|off)$' { return $false }
        default { return $Default }
    }
}

function ConvertTo-StringArray {
    param($Value)
    if ($null -eq $Value) { return @() }
    if ($Value -is [string]) {
        if ([string]::IsNullOrWhiteSpace($Value)) { return @() }
        return @($Value)
    }
    $items = New-Object 'System.Collections.Generic.List[string]'
    foreach ($item in @($Value)) {
        $text = [string]$item
        if (-not [string]::IsNullOrWhiteSpace($text)) { $items.Add($text) }
    }
    return @($items.ToArray())
}

function Test-IsCollection {
    param($Value)
    if ($null -eq $Value) { return $false }
    if ($Value -is [string]) { return $false }
    if ($Value -is [System.Collections.IDictionary]) { return $false }
    if ($Value -is [pscustomobject]) { return $false }
    return $Value -is [System.Collections.IEnumerable]
}

function ConvertTo-ObjectArray {
    param($Value)
    if ($null -eq $Value) { return @() }
    if (Test-IsCollection $Value) { return @($Value) }
    return @($Value)
}

function Get-HttpStatusCode {
    param($ErrorRecord)
    if ($null -eq $ErrorRecord) { return 0 }

    $exception = $ErrorRecord.Exception
    while ($null -ne $exception) {
        try {
            $status = Get-PropertyValue -InputObject $exception -Name 'StatusCode' -Default $null
            if ($null -ne $status) { return [int]$status }
        }
        catch { }

        try {
            $response = Get-PropertyValue -InputObject $exception -Name 'Response' -Default $null
            if ($null -ne $response) {
                $status = Get-PropertyValue -InputObject $response -Name 'StatusCode' -Default $null
                if ($null -ne $status) { return [int]$status }
            }
        }
        catch { }

        $exception = Get-PropertyValue -InputObject $exception -Name 'InnerException' -Default $null
    }
    return 0
}

function ConvertTo-JsonStringEscaped {
    param([string] $Text)
    if ($null -eq $Text) { return '' }
    $builder = New-Object System.Text.StringBuilder ($Text.Length + 16)
    foreach ($char in $Text.ToCharArray()) {
        $code = [int]$char
        switch ($code) {
            34 { [void]$builder.Append('\"') }
            92 { [void]$builder.Append('\\') }
            8 { [void]$builder.Append('\b') }
            12 { [void]$builder.Append('\f') }
            10 { [void]$builder.Append('\n') }
            13 { [void]$builder.Append('\r') }
            9 { [void]$builder.Append('\t') }
            default {
                if ($code -lt 32) {
                    [void]$builder.Append(('\u{0:x4}' -f $code))
                }
                else {
                    [void]$builder.Append($char)
                }
            }
        }
    }
    return $builder.ToString()
}

function ConvertTo-StableJson {
    <#
    .SYNOPSIS
        JSON serializer that never unwraps single-element arrays.
        ConvertTo-Json does, which breaks VECTR GraphQL list inputs.
    #>
    param($Value, [int] $Depth = 0, [int] $MaxDepth = 40)

    if ($Depth -gt $MaxDepth) { return 'null' }
    if ($null -eq $Value) { return 'null' }
    if ($Value -is [DBNull]) { return 'null' }

    if ($Value -is [bool]) {
        if ($Value) { return 'true' } else { return 'false' }
    }

    if ($Value -is [byte] -or $Value -is [int16] -or $Value -is [uint16] -or
        $Value -is [int] -or $Value -is [uint32] -or $Value -is [long] -or
        $Value -is [uint64] -or $Value -is [decimal] -or $Value -is [double] -or
        $Value -is [float] -or $Value -is [single]) {
        return [Convert]::ToString($Value, [Globalization.CultureInfo]::InvariantCulture)
    }

    if ($Value -is [datetimeoffset]) {
        return ('"{0}"' -f $Value.ToString('o'))
    }
    if ($Value -is [datetime]) {
        return ('"{0}"' -f $Value.ToString('o'))
    }

    if ($Value -is [enum]) {
        return ('"{0}"' -f (ConvertTo-JsonStringEscaped ([string]$Value)))
    }

    if ($Value -is [string] -or $Value -is [char] -or $Value -is [guid]) {
        return ('"{0}"' -f (ConvertTo-JsonStringEscaped ([string]$Value)))
    }

    if ($Value -is [System.Collections.IDictionary]) {
        $parts = New-Object 'System.Collections.Generic.List[string]'
        foreach ($key in $Value.Keys) {
            $parts.Add(('"{0}":{1}' -f (ConvertTo-JsonStringEscaped ([string]$key)), (ConvertTo-StableJson -Value $Value[$key] -Depth ($Depth + 1) -MaxDepth $MaxDepth)))
        }
        return ('{{{0}}}' -f ($parts -join ','))
    }

    if ($Value -is [pscustomobject]) {
        $parts = New-Object 'System.Collections.Generic.List[string]'
        foreach ($property in $Value.PSObject.Properties) {
            $parts.Add(('"{0}":{1}' -f (ConvertTo-JsonStringEscaped $property.Name), (ConvertTo-StableJson -Value $property.Value -Depth ($Depth + 1) -MaxDepth $MaxDepth)))
        }
        return ('{{{0}}}' -f ($parts -join ','))
    }

    if (Test-IsCollection $Value) {
        $parts = New-Object 'System.Collections.Generic.List[string]'
        foreach ($item in $Value) {
            $parts.Add((ConvertTo-StableJson -Value $item -Depth ($Depth + 1) -MaxDepth $MaxDepth))
        }
        return ('[{0}]' -f ($parts -join ','))
    }

    return ('"{0}"' -f (ConvertTo-JsonStringEscaped ([string]$Value)))
}

function ConvertTo-DebugJson {
    param($Value)
    try {
        return (ConvertTo-StableJson -Value $Value)
    }
    catch {
        return "<unable to serialize debug value: $($_.Exception.Message)>"
    }
}

function Get-RedactedHeaders {
    param([Parameter(Mandatory = $true)] [hashtable] $Headers)

    $safeHeaders = [ordered]@{}
    foreach ($name in $Headers.Keys) {
        if ([string]$name -match '^(?i:authorization|proxy-authorization|x-token|api-key|x-api-key|cookie|set-cookie)$') {
            $safeHeaders[[string]$name] = '<redacted>'
        }
        else {
            $safeHeaders[[string]$name] = $Headers[$name]
        }
    }
    return $safeHeaders
}

function Wait-CymulateRateLimit {
    # Cymulate: 30 requests per 10 seconds per IP.
    $window = [TimeSpan]::FromSeconds(10)
    $max = 28
    $now = [datetime]::UtcNow
    while ($script:CymulateRequestTimes.Count -gt 0 -and ($now - $script:CymulateRequestTimes.Peek()) -gt $window) {
        [void]$script:CymulateRequestTimes.Dequeue()
    }
    if ($script:CymulateRequestTimes.Count -ge $max) {
        $waitMs = [int](($window - ($now - $script:CymulateRequestTimes.Peek())).TotalMilliseconds + 50)
        if ($waitMs -gt 0) {
            Write-Verbose "Cymulate rate limit: waiting ${waitMs}ms (30 req / 10s)."
            Start-Sleep -Milliseconds $waitMs
        }
        $now = [datetime]::UtcNow
        while ($script:CymulateRequestTimes.Count -gt 0 -and ($now - $script:CymulateRequestTimes.Peek()) -gt $window) {
            [void]$script:CymulateRequestTimes.Dequeue()
        }
    }
    $script:CymulateRequestTimes.Enqueue([datetime]::UtcNow)
}

function Invoke-JsonRequest {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)] [ValidateSet('GET', 'POST', 'PATCH', 'PUT', 'DELETE')] [string] $Method,
        [Parameter(Mandatory = $true)] [string] $Uri,
        [Parameter(Mandatory = $true)] [hashtable] $Headers,
        $Body,
        [int] $MaxAttempts = 4,
        [int] $TimeoutSec = 100,
        [bool] $SkipCertificateCheck = $false,
        [bool] $CymulateRateLimit = $false
    )

    $restCommand = Get-Command Invoke-RestMethod
    if ($SkipCertificateCheck -and -not $restCommand.Parameters.ContainsKey('SkipCertificateCheck')) {
        throw 'SkipCertificateCheck requires PowerShell 7 or later. Use a trusted VECTR certificate or run this script with pwsh.'
    }

    if ($CymulateRateLimit) { Wait-CymulateRateLimit }

    for ($attempt = 1; $attempt -le $MaxAttempts; $attempt++) {
        $params = @{
            Method      = $Method
            Uri         = $Uri
            Headers     = $Headers
            TimeoutSec  = $TimeoutSec
            ErrorAction = 'Stop'
            Debug       = $false
            Verbose     = $false
        }
        if ($null -ne $Body) {
            $params.ContentType = 'application/json'
            $params.Body = ConvertTo-StableJson -Value $Body
        }
        if ($SkipCertificateCheck) { $params.SkipCertificateCheck = $true }

        Write-Verbose "HTTP request attempt $attempt of $MaxAttempts`: $Method $Uri"
        Write-Debug "HTTP request headers (secrets redacted):`n$(ConvertTo-DebugJson (Get-RedactedHeaders -Headers $Headers))"
        if ($null -ne $Body) {
            Write-Debug "HTTP request JSON body:`n$(ConvertTo-DebugJson $Body)"
        }
        else {
            Write-Debug 'HTTP request body: <none>'
        }

        try {
            $response = Invoke-RestMethod @params
            Write-Debug "HTTP response for $Method $Uri`:`n$(ConvertTo-DebugJson $response)"
            return $response
        }
        catch {
            $statusCode = Get-HttpStatusCode -ErrorRecord $_
            $errorBody = [string](Get-FirstPropertyValue -InputObject $_.ErrorDetails -Names @('Message') -Default '')
            Write-Verbose "HTTP request failed with status $statusCode for $Method $Uri. Exception: $($_.Exception.Message)"
            if (-not [string]::IsNullOrWhiteSpace($errorBody)) {
                Write-Debug "HTTP error response body:`n$errorBody"
            }
            $retryable = $statusCode -eq 0 -or $statusCode -eq 408 -or $statusCode -eq 429 -or $statusCode -ge 500
            if (-not $retryable -or $attempt -eq $MaxAttempts) {
                $detail = $errorBody
                if ([string]::IsNullOrWhiteSpace($detail)) { $detail = [string]$_.Exception.Message }
                if ($detail.Length -gt 800) { $detail = $detail.Substring(0, 800) }
                throw "HTTP request failed ($statusCode) for $Method $Uri. $detail"
            }

            $delaySeconds = [Math]::Min(30, [Math]::Pow(2, $attempt - 1))
            Write-Verbose "Request failed with HTTP $statusCode. Retrying in $delaySeconds second(s) (attempt $attempt of $MaxAttempts)."
            Start-Sleep -Seconds $delaySeconds
        }
    }
}

function Get-VectrAuthorizationValue {
    param([Parameter(Mandatory = $true)] [string] $ApiKey)
    $trimmed = $ApiKey.Trim()
    if ($trimmed -match '^(?i:VEC1|Bearer|VECTR)\s+\S') { return $trimmed }
    return "VEC1 $trimmed"
}

function Invoke-VectrGraphQl {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)] [string] $Uri,
        [Parameter(Mandatory = $true)] [string] $ApiKey,
        [Parameter(Mandatory = $true)] [string] $Query,
        [Parameter(Mandatory = $true)] [hashtable] $Variables,
        [string] $OperationName,
        [int] $TimeoutSec = 100,
        [bool] $SkipCertificateCheck = $false
    )

    $body = @{ query = $Query; variables = $Variables }
    if (-not [string]::IsNullOrWhiteSpace($OperationName)) { $body.operationName = $OperationName }
    $headers = @{
        Authorization  = (Get-VectrAuthorizationValue -ApiKey $ApiKey)
        Accept         = 'application/json'
        'Content-Type' = 'application/json'
    }
    $response = Invoke-JsonRequest -Method POST -Uri $Uri -Headers $headers -Body $body -TimeoutSec $TimeoutSec -SkipCertificateCheck $SkipCertificateCheck

    $errors = @(ConvertTo-ObjectArray (Get-PropertyValue -InputObject $response -Name 'errors' -Default @()))
    if ($errors.Count -gt 0) {
        $messages = @($errors | ForEach-Object { [string](Get-PropertyValue -InputObject $_ -Name 'message' -Default 'Unknown GraphQL error') })
        throw "VECTR GraphQL error: $($messages -join '; ')"
    }
    return Get-PropertyValue -InputObject $response -Name 'data'
}

function Get-DateWindow {
    param(
        [Parameter(Mandatory = $true)] [datetime] $StartDate,
        [Parameter(Mandatory = $true)] [datetime] $EndDate,
        [string] $TimeZoneId
    )

    if ($EndDate.Date -lt $StartDate.Date) {
        throw 'EndDate must be the same as or later than StartDate.'
    }

    $timeZone = if ([string]::IsNullOrWhiteSpace($TimeZoneId)) {
        [TimeZoneInfo]::Local
    }
    else {
        [TimeZoneInfo]::FindSystemTimeZoneById($TimeZoneId)
    }

    $startLocal = [DateTime]::SpecifyKind($StartDate.Date, [DateTimeKind]::Unspecified)
    $endLocal = [DateTime]::SpecifyKind($EndDate.Date.AddDays(1), [DateTimeKind]::Unspecified)
    [pscustomobject]@{
        TimeZone       = $timeZone
        StartUtc       = [TimeZoneInfo]::ConvertTimeToUtc($startLocal, $timeZone)
        EndUtc         = [TimeZoneInfo]::ConvertTimeToUtc($endLocal, $timeZone)
        StartLocalDate = $startLocal.ToString('yyyy-MM-dd', [Globalization.CultureInfo]::InvariantCulture)
        EndLocalDate   = $EndDate.Date.ToString('yyyy-MM-dd', [Globalization.CultureInfo]::InvariantCulture)
    }
}

function New-QueryString {
    param([Parameter(Mandatory = $true)] [hashtable] $Parameters)
    $parts = foreach ($key in ($Parameters.Keys | Sort-Object)) {
        foreach ($value in @(ConvertTo-ObjectArray $Parameters[$key])) {
            if ($null -ne $value -and -not [string]::IsNullOrWhiteSpace([string]$value)) {
                '{0}={1}' -f [Uri]::EscapeDataString([string]$key), [Uri]::EscapeDataString([string]$value)
            }
        }
    }
    return (($parts | Where-Object { -not [string]::IsNullOrWhiteSpace($_) }) -join '&')
}

function Join-UrlPath {
    param(
        [Parameter(Mandatory = $true)] [string] $BaseUrl,
        [Parameter(Mandatory = $true)] [string] $Path
    )
    return '{0}/{1}' -f $BaseUrl.TrimEnd('/'), $Path.TrimStart('/')
}

function Get-ResponseItems {
    param(
        $Response,
        [string[]] $PreferredKeys = @('findings', 'data', 'items', 'results', 'nodes', 'assessments', 'scenarios')
    )

    if ($null -eq $Response) { return @() }
    if (Test-IsCollection $Response) { return @(ConvertTo-ObjectArray $Response) }

    foreach ($key in $PreferredKeys) {
        $value = Get-PropertyValue -InputObject $Response -Name $key -Default $null
        if ($null -eq $value) { continue }
        if (Test-IsCollection $value) { return @(ConvertTo-ObjectArray $value) }

        if ($value -is [pscustomobject] -or $value -is [System.Collections.IDictionary]) {
            foreach ($nested in @('findings', 'items', 'results', 'nodes', 'data', 'assessments', 'scenarios', 'list')) {
                $inner = Get-PropertyValue -InputObject $value -Name $nested -Default $null
                if (Test-IsCollection $inner) { return @(ConvertTo-ObjectArray $inner) }
                if ($null -ne $inner -and -not ($inner -is [string]) -and ($null -ne (Get-FirstPropertyValue -InputObject $inner -Names @('id', '_id') -Default $null))) {
                    return @($inner)
                }
            }
            if ($null -ne (Get-FirstPropertyValue -InputObject $value -Names @('id', '_id') -Default $null)) {
                return @($value)
            }
        }
    }
    return @()
}

function Get-ResponseCursor {
    param($Response)
    $candidates = @(
        (Get-FirstPropertyValue -InputObject $Response -Names @('nextCursor', 'next_cursor', 'cursor', 'nextPageToken', 'next_page_token') -Default $null)
    )
    $data = Get-PropertyValue -InputObject $Response -Name 'data' -Default $null
    $pagination = Get-FirstPropertyValue -InputObject $Response -Names @('pagination', 'pageInfo', 'meta') -Default $null
    $candidates += Get-FirstPropertyValue -InputObject $data -Names @('nextCursor', 'next_cursor', 'cursor', 'nextPageToken') -Default $null
    $candidates += Get-FirstPropertyValue -InputObject $pagination -Names @('nextCursor', 'next_cursor', 'cursor', 'nextPageToken', 'endCursor') -Default $null

    foreach ($candidate in $candidates) {
        $text = [string]$candidate
        if (-not [string]::IsNullOrWhiteSpace($text) -and $text -notin @('null', 'None', 'undefined')) {
            return $text.Trim()
        }
    }
    return ''
}

function Get-ResponseNextLink {
    param($Response)
    $value = Get-FirstPropertyValue -InputObject $Response -Names @('next') -Default $null
    $text = [string]$value
    if ([string]::IsNullOrWhiteSpace($text) -or $text -in @('null', 'None', 'undefined')) { return '' }
    return $text.Trim()
}

function Resolve-NextUri {
    param(
        [string] $Next,
        [string] $UriBase
    )
    if ([string]::IsNullOrWhiteSpace($Next)) { return '' }
    if ($Next -match '^(?i)https?://') { return $Next }
    if ($Next.StartsWith('/')) {
        try {
            $origin = [Uri]$UriBase
            return ([Uri]::new($origin, $Next)).AbsoluteUri
        }
        catch {
            return $Next
        }
    }
    return ''
}

function Get-ResponseTotalCount {
    param($Response, [int] $Fallback)
    $candidates = @(
        (Get-FirstPropertyValue -InputObject $Response -Names @('count', 'total', 'totalCount', 'totalItems', 'total_count') -Default $null)
    )
    $data = Get-PropertyValue -InputObject $Response -Name 'data' -Default $null
    $pagination = Get-FirstPropertyValue -InputObject $Response -Names @('pagination', 'pageInfo', 'meta') -Default $null
    $candidates += Get-FirstPropertyValue -InputObject $data -Names @('count', 'total', 'totalCount', 'totalItems') -Default $null
    $candidates += Get-FirstPropertyValue -InputObject $pagination -Names @('count', 'total', 'totalCount', 'totalItems', 'total_count') -Default $null
    foreach ($candidate in $candidates) {
        if ($null -eq $candidate) { continue }
        if ($candidate -is [System.Collections.IEnumerable] -and -not ($candidate -is [string])) { continue }
        try {
            $number = [int]$candidate
            if ($number -ge 0) { return $number }
        }
        catch { }
    }
    return $Fallback
}

function Test-ResponseHasMore {
    param($Response, [string] $Cursor, [int] $ItemCount, [int] $PageSize, [int] $Accumulated, [int] $TotalCount)
    if (-not [string]::IsNullOrWhiteSpace($Cursor)) { return $true }
    foreach ($container in @($Response, (Get-PropertyValue $Response 'pagination' $null), (Get-PropertyValue $Response 'pageInfo' $null), (Get-PropertyValue $Response 'data' $null))) {
        $flag = Get-FirstPropertyValue -InputObject $container -Names @('hasMore', 'has_more', 'hasNext', 'hasNextPage', 'has_next_page') -Default $null
        if ($flag -is [bool]) { return $flag }
        if ($null -ne $flag) {
            $asBool = ConvertTo-Boolean -Value $flag -Default $false
            if ($asBool) { return $true }
            $asText = [string]$flag
            if ($asText -match '^(?i:false|0|no)$') { return $false }
        }
    }
    if ($ItemCount -le 0) { return $false }
    if ($TotalCount -gt 0 -and $Accumulated -lt $TotalCount) { return $true }
    if ($PageSize -gt 0 -and $ItemCount -ge $PageSize) { return $true }
    return $false
}

function Invoke-CymulatePagedGet {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)] [string] $UriBase,
        [Parameter(Mandatory = $true)] [hashtable] $Headers,
        [hashtable] $Query = @{},
        [int] $PageSize = 25,
        [int] $MaxPages = 1000,
        [int] $TimeoutSec = 100,
        [bool] $SkipCertificateCheck = $false,
        [string[]] $ItemKeys = @('data', 'findings', 'items', 'results'),
        [string] $ProgressLabel = 'items'
    )

    $all = New-Object 'System.Collections.Generic.List[object]'
    $page = 1
    $cursor = ''
    $nextUri = ''
    $seenTokens = New-Object 'System.Collections.Generic.HashSet[string]'

    do {
        if (-not [string]::IsNullOrWhiteSpace($nextUri)) {
            $uri = $nextUri
            $nextUri = ''
        }
        else {
            $queryParams = @{}
            foreach ($key in $Query.Keys) { $queryParams[$key] = $Query[$key] }
            $queryParams['limit'] = $PageSize
            if (-not [string]::IsNullOrWhiteSpace($cursor)) {
                $queryParams['cursor'] = $cursor
            }
            else {
                $queryParams['page'] = $page
            }
            $qs = New-QueryString -Parameters $queryParams
            $uri = if ([string]::IsNullOrWhiteSpace($qs)) { $UriBase } else { '{0}?{1}' -f $UriBase, $qs }
        }

        Write-Verbose "Reading Cymulate $ProgressLabel page $page (have $($all.Count) so far): $uri"
        $response = Invoke-JsonRequest -Method GET -Uri $uri -Headers $Headers -TimeoutSec $TimeoutSec -SkipCertificateCheck $SkipCertificateCheck -CymulateRateLimit $true
        $items = @(Get-ResponseItems -Response $response -PreferredKeys $ItemKeys)
        foreach ($item in $items) { $all.Add($item) }

        $total = Get-ResponseTotalCount -Response $response -Fallback -1
        $nextCursor = Get-ResponseCursor -Response $response
        $nextLink = Resolve-NextUri -Next (Get-ResponseNextLink -Response $response) -UriBase $UriBase

        $token = if (-not [string]::IsNullOrWhiteSpace($nextLink)) { $nextLink } else { $nextCursor }
        if (-not [string]::IsNullOrWhiteSpace($token)) {
            if (-not $seenTokens.Add($token)) {
                Write-Verbose "Cymulate returned a repeated pagination token; stopping $ProgressLabel."
                break
            }
        }

        $hasMore = $false
        if (-not [string]::IsNullOrWhiteSpace($nextLink)) {
            $nextUri = $nextLink
            $hasMore = $true
        }
        elseif (-not [string]::IsNullOrWhiteSpace($nextCursor)) {
            $cursor = $nextCursor
            $hasMore = $true
        }
        else {
            $cursor = ''
            $hasMore = Test-ResponseHasMore -Response $response -Cursor '' -ItemCount $items.Count -PageSize $PageSize -Accumulated $all.Count -TotalCount $total
        }
        $page++
    } while ($hasMore -and $page -le $MaxPages)

    if ($page -gt $MaxPages) {
        Write-Warning "Stopped paging $ProgressLabel after $MaxPages pages ($($all.Count) item(s) collected)."
    }
    Write-Verbose "Finished reading Cymulate $ProgressLabel. Collected $($all.Count) item(s)."
    return @($all.ToArray())
}

function Get-AssessmentId {
    param($Assessment)
    $value = [string](Get-FirstPropertyValue -InputObject $Assessment -Names @('id', '_id', 'assessmentId', 'launchedAssessmentId', 'scenarioId') -Default '')
    return $value.Trim()
}

function Get-AssessmentStatus {
    param($Assessment)
    return ([string](Get-FirstPropertyValue -InputObject $Assessment -Names @('status', 'state', 'assessmentStatus') -Default '')).Trim()
}

function Get-AssessmentTimestamp {
    param($Assessment)
    $text = [string](Get-FirstPropertyValue -InputObject $Assessment -Names @('startedAt', 'startDate', 'launchedAt', 'createdAt', 'created', 'timestamp') -Default '')
    if ([string]::IsNullOrWhiteSpace($text)) { return $null }
    try {
        return [DateTimeOffset]::Parse($text, [Globalization.CultureInfo]::InvariantCulture, [Globalization.DateTimeStyles]::AssumeUniversal)
    }
    catch {
        try { return [DateTimeOffset]::Parse($text) }
        catch { return $null }
    }
}

function Test-CompletedStatus {
    param([string] $Status, [bool] $IncludePartiallyCompleted = $false)
    if ([string]::IsNullOrWhiteSpace($Status)) { return $false }
    if ($Status -match '(?i)^(completed|complete)$') { return $true }
    if ($IncludePartiallyCompleted -and $Status -match '(?i)^partially[\s_-]*completed$') { return $true }
    return $false
}

function Get-CymulateAssessments {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)] [string] $BaseUrl,
        [Parameter(Mandatory = $true)] [string] $LaunchedAssessmentsPath,
        [Parameter(Mandatory = $true)] [string] $Token,
        [Parameter(Mandatory = $true)] $DateWindow,
        [int] $PageSize = 25,
        [int] $MaxPages = 1000,
        [int] $TimeoutSec = 100,
        [bool] $SkipCertificateCheck = $false,
        [bool] $IncludePartiallyCompleted = $false
    )

    $headers = @{ 'x-token' = $Token; Accept = 'application/json' }
    $uriBase = Join-UrlPath -BaseUrl $BaseUrl -Path $LaunchedAssessmentsPath
    $statusValues = New-Object 'System.Collections.Generic.List[string]'
    $statusValues.Add('completed')
    if ($IncludePartiallyCompleted) { $statusValues.Add('partiallyCompleted') }
    $query = @{
        sortBy    = 'created'
        sortOrder = 'desc'
        status    = @($statusValues.ToArray())
        fromDate  = $DateWindow.StartUtc.ToString('yyyy-MM-ddTHH:mm:ss.fffZ', [Globalization.CultureInfo]::InvariantCulture)
        toDate    = $DateWindow.EndUtc.ToString('yyyy-MM-ddTHH:mm:ss.fffZ', [Globalization.CultureInfo]::InvariantCulture)
    }
    $all = @(Invoke-CymulatePagedGet -UriBase $uriBase -Headers $headers -Query $query -PageSize $PageSize -MaxPages $MaxPages -TimeoutSec $TimeoutSec -SkipCertificateCheck $SkipCertificateCheck -ItemKeys @('data', 'assessments', 'items', 'results') -ProgressLabel 'launched assessments')

    $completedCount = 0
    $missingDateCount = 0
    $outsideDateCount = 0
    $selected = New-Object 'System.Collections.Generic.List[object]'

    foreach ($assessment in $all) {
        $assessmentId = Get-AssessmentId -Assessment $assessment
        if ([string]::IsNullOrWhiteSpace($assessmentId)) { $assessmentId = 'unknown' }
        $assessmentStatus = Get-AssessmentStatus -Assessment $assessment
        if (-not [string]::IsNullOrWhiteSpace($assessmentStatus) -and -not (Test-CompletedStatus -Status $assessmentStatus -IncludePartiallyCompleted $IncludePartiallyCompleted)) {
            Write-Verbose "[Cymulate filter] EXCLUDED id='$assessmentId'; status='$assessmentStatus'; reason=status is not completed."
            continue
        }
        $completedCount++

        $dateValue = Get-AssessmentTimestamp -Assessment $assessment
        if ($null -eq $dateValue) {
            $missingDateCount++
            Write-Verbose "[Cymulate filter] EXCLUDED id='$assessmentId'; status='$assessmentStatus'; reason=no startedAt/created timestamp."
            Write-Warning "Assessment '$assessmentId' has no usable start timestamp and was skipped."
            continue
        }
        if ($dateValue.UtcDateTime -ge $DateWindow.StartUtc -and $dateValue.UtcDateTime -lt $DateWindow.EndUtc) {
            Write-Verbose "[Cymulate filter] INCLUDED id='$assessmentId'; status='$assessmentStatus'; parsedUtc='$($dateValue.UtcDateTime.ToString('o'))'."
            $selected.Add($assessment)
        }
        else {
            $outsideDateCount++
            Write-Verbose "[Cymulate filter] EXCLUDED id='$assessmentId'; status='$assessmentStatus'; parsedUtc='$($dateValue.UtcDateTime.ToString('o'))'; reason=outside UTC [$($DateWindow.StartUtc.ToString('o')), $($DateWindow.EndUtc.ToString('o')))."
        }
    }

    Write-Verbose "[Cymulate filter summary] API items=$($all.Count); Completed-or-empty-status=$completedCount; MissingTimestamp=$missingDateCount; OutsideDateRange=$outsideDateCount; Selected=$($selected.Count); UTC window=[$($DateWindow.StartUtc.ToString('o')), $($DateWindow.EndUtc.ToString('o')))."
    if ($selected.Count -eq 0) {
        Write-Warning "No Cymulate launched assessments passed the local filter. API items=$($all.Count), completed-or-empty-status=$completedCount, missing timestamp=$missingDateCount, outside date range=$outsideDateCount. UTC window=[$($DateWindow.StartUtc.ToString('o')), $($DateWindow.EndUtc.ToString('o')))."
    }
    return @($selected.ToArray())
}

function Get-CymulateFindings {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)] [string] $BaseUrl,
        [Parameter(Mandatory = $true)] [string] $LaunchedAssessmentsPath,
        [Parameter(Mandatory = $true)] [string] $Token,
        [Parameter(Mandatory = $true)] [string] $AssessmentId,
        [string] $FindingsPathTemplate = '',
        [int] $PageSize = 25,
        [int] $MaxPages = 1000,
        [int] $TimeoutSec = 100,
        [bool] $SkipCertificateCheck = $false
    )

    $headers = @{ 'x-token' = $Token; Accept = 'application/json' }
    $encodedId = [Uri]::EscapeDataString($AssessmentId)
    if ([string]::IsNullOrWhiteSpace($FindingsPathTemplate)) {
        $uriBase = '{0}/{1}/findings' -f (Join-UrlPath -BaseUrl $BaseUrl -Path $LaunchedAssessmentsPath), $encodedId
    }
    else {
        $path = $FindingsPathTemplate.Replace('{id}', $encodedId).Replace('{launched}', $LaunchedAssessmentsPath.Trim('/'))
        $uriBase = Join-UrlPath -BaseUrl $BaseUrl -Path $path
    }
    if ($PageSize -gt 100) { $PageSize = 100 }
    if ($PageSize -lt 1) { $PageSize = 25 }
    return @(Invoke-CymulatePagedGet -UriBase $uriBase -Headers $headers -Query @{} -PageSize $PageSize -MaxPages $MaxPages -TimeoutSec $TimeoutSec -SkipCertificateCheck $SkipCertificateCheck -ItemKeys @('findings', 'data', 'items', 'results') -ProgressLabel "findings for $AssessmentId")
}

function Get-EpochMilliseconds {
    param([string] $DateText)
    if ([string]::IsNullOrWhiteSpace($DateText)) { return $null }
    try {
        return [double]([DateTimeOffset]::Parse($DateText, [Globalization.CultureInfo]::InvariantCulture, [Globalization.DateTimeStyles]::AssumeUniversal).ToUnixTimeMilliseconds())
    }
    catch {
        try { return [double]([DateTimeOffset]::Parse($DateText).ToUnixTimeMilliseconds()) }
        catch { return $null }
    }
}

function Limit-Text {
    param([string] $Text, [int] $MaxLength)
    if ($null -eq $Text) { return '' }
    if ($Text.Length -le $MaxLength) { return $Text }
    return $Text.Substring(0, [Math]::Max(0, $MaxLength - 16)) + "`n[truncated]"
}

function Get-FindingName {
    param($Finding)
    return ([string](Get-FirstPropertyValue -InputObject $Finding -Names @('findingName', 'name', 'title', 'type', 'findingType', 'displayName') -Default '')).Trim()
}

function Test-SiemAlertFindingName {
    param(
        [string] $FindingName,
        [string[]] $Patterns
    )
    if ([string]::IsNullOrWhiteSpace($FindingName)) { return $false }
    foreach ($pattern in $Patterns) {
        if ([string]::IsNullOrWhiteSpace($pattern)) { continue }
        if ($FindingName -ceq $pattern) { return $true }
        if ($FindingName -like $pattern) { return $true }
    }
    return $false
}

function Get-MitreEntry {
    param(
        $Finding,
        [Parameter(Mandatory = $true)] [string[]] $PropertyNames
    )

    $values = $null
    foreach ($name in $PropertyNames) {
        $values = Get-PropertyValue -InputObject $Finding -Name $name -Default $null
        if ($null -ne $values) { break }
    }
    $entries = @(ConvertTo-ObjectArray $values)
    foreach ($entry in $entries) {
        if ($null -eq $entry) { continue }
        if ($entry -is [string]) {
            $text = $entry.Trim()
            if ([string]::IsNullOrWhiteSpace($text)) { continue }
            $id = $text
            $name = $text
            if ($text -match '^(TA\d{4}|T\d{4}(?:\.\d{3})?)\s*[|:–-]\s*(.+)$') {
                $id = $Matches[1]
                $name = $Matches[2].Trim()
            }
            return [pscustomobject]@{ Id = $id; Name = $name }
        }
        $id = [string](Get-FirstPropertyValue -InputObject $entry -Names @('mitreID', 'mitreId', 'id', 'techniqueId', 'tacticId', 'externalId') -Default '')
        $name = [string](Get-FirstPropertyValue -InputObject $entry -Names @('name', 'displayName', 'title') -Default '')
        if (-not [string]::IsNullOrWhiteSpace($id) -or -not [string]::IsNullOrWhiteSpace($name)) {
            return [pscustomobject]@{ Id = $id.Trim(); Name = $name.Trim() }
        }
    }
    return $null
}

function Get-FindingScenarioKey {
    param($Finding, [string] $AssessmentId)
    # Do not use finding.clientId — that is the Cymulate tenant id, not a scenario key.
    $key = [string](Get-FirstPropertyValue -InputObject $Finding -Names @(
            'testCaseKey', 'testCase', 'scenarioId', 'scenario_id', 'findingsNameKey'
        ) -Default '')
    if (-not [string]::IsNullOrWhiteSpace($key)) { return $key.Trim() }

    $name = [string](Get-FirstPropertyValue -InputObject $Finding -Names @('scenarioName', 'actionName', 'scenario', 'action') -Default '')
    if (-not [string]::IsNullOrWhiteSpace($name)) { return "$AssessmentId::$($name.Trim())" }

    $findingId = [string](Get-FirstPropertyValue -InputObject $Finding -Names @('id', '_id', 'findingId') -Default '')
    if (-not [string]::IsNullOrWhiteSpace($findingId)) { return $findingId.Trim() }
    return [guid]::NewGuid().ToString('N')
}

function Get-FindingScenarioName {
    param($Finding, $Assessment, [string] $Fallback)
    $name = [string](Get-FirstPropertyValue -InputObject $Finding -Names @('scenarioName', 'testCase', 'actionName', 'scenario', 'action', 'testName') -Default '')
    if (-not [string]::IsNullOrWhiteSpace($name)) { return $name.Trim() }
    $assessmentName = [string](Get-FirstPropertyValue -InputObject $Assessment -Names @('name', 'assessmentName', 'title', 'templateName') -Default '')
    if (-not [string]::IsNullOrWhiteSpace($assessmentName)) { return $assessmentName.Trim() }
    return $Fallback
}

function Get-AssessmentTargets {
    param($Assessment)
    $raw = Get-FirstPropertyValue -InputObject $Assessment -Names @('targets', 'agents', 'endpoints', 'machines', 'target') -Default @()
    $names = New-Object 'System.Collections.Generic.List[string]'
    foreach ($item in @(ConvertTo-ObjectArray $raw)) {
        if ($null -eq $item) { continue }
        if ($item -is [string]) {
            $parts = @($item -split '\s+' | Where-Object { -not [string]::IsNullOrWhiteSpace($_) })
            if ($parts.Count -gt 0) { $names.Add($parts[0]); continue }
        }
        $candidate = [string](Get-FirstPropertyValue -InputObject $item -Names @('hostname', 'name', 'agentName', 'address', 'ip', 'fqdn') -Default '')
        if (-not [string]::IsNullOrWhiteSpace($candidate)) { $names.Add($candidate.Trim()) }
    }
    return @($names.ToArray())
}

function ConvertTo-TestCaseInput {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)] $Assessment,
        [Parameter(Mandatory = $true)] $SiemFinding,
        [Parameter(Mandatory = $true)] [string] $Organization,
        [Parameter(Mandatory = $true)] [string] $ScenarioKey,
        [int] $MaxTextLength = 8000,
        [bool] $MapDetectionToOutcome = $true
    )

    $assessmentId = Get-AssessmentId -Assessment $Assessment
    if ([string]::IsNullOrWhiteSpace($assessmentId)) { throw 'A date-filtered launched assessment has no id.' }

    $scenarioName = Get-FindingScenarioName -Finding $SiemFinding -Assessment $Assessment -Fallback $assessmentId
    $startedAt = [string](Get-FirstPropertyValue -InputObject $Assessment -Names @('startedAt', 'startDate', 'launchedAt', 'createdAt', 'created') -Default '')
    $endedAt = [string](Get-FirstPropertyValue -InputObject $SiemFinding -Names @('endTime', 'date') -Default '')
    if ([string]::IsNullOrWhiteSpace($endedAt) -or $endedAt -eq 'System.Object' -or $endedAt.StartsWith('@{')) {
        $endedAt = [string](Get-FirstPropertyValue -InputObject $Assessment -Names @('updatedAt', 'endedAt', 'endDate', 'completedAt', 'finishedAt') -Default $startedAt)
    }
    if ([string]::IsNullOrWhiteSpace($startedAt)) { throw "Launched assessment '$assessmentId' has no start timestamp (startedAt/createdAt)." }

    $targets = @(Get-AssessmentTargets -Assessment $Assessment)
    $technique = Get-MitreEntry -Finding $SiemFinding -PropertyNames @('techniques', 'technique', 'mitreTechniques')
    $tactic = Get-MitreEntry -Finding $SiemFinding -PropertyNames @('tactics', 'tactic', 'mitreTactics', 'phase', 'phases')
    if ($null -eq $technique -or ([string]::IsNullOrWhiteSpace($technique.Id) -and [string]::IsNullOrWhiteSpace($technique.Name))) {
        throw "Finding for assessment '$assessmentId' scenario '$ScenarioKey' has no MITRE technique."
    }
    if ($null -eq $tactic -or ([string]::IsNullOrWhiteSpace($tactic.Id) -and [string]::IsNullOrWhiteSpace($tactic.Name))) {
        throw "Finding for assessment '$assessmentId' scenario '$ScenarioKey' has no MITRE tactic/phase."
    }

    $techniqueId = if (-not [string]::IsNullOrWhiteSpace($technique.Id)) { $technique.Id } else { $technique.Name }
    $phase = if (-not [string]::IsNullOrWhiteSpace($tactic.Name) -and $tactic.Name -notmatch '^TA\d{4}$') { $tactic.Name } else { $tactic.Id }
    if ([string]::IsNullOrWhiteSpace($phase)) { $phase = $tactic.Name }

    $detection = [string](Get-FirstPropertyValue -InputObject $SiemFinding -Names @('detection', 'result', 'status', 'outcome') -Default '')
    $templateId = [string](Get-FirstPropertyValue -InputObject $Assessment -Names @('templateId', 'template_id', 'templateName') -Default '')
    $templateName = if (-not [string]::IsNullOrWhiteSpace($templateId)) { "Cymulate $templateId" } else { "Cymulate $scenarioName" }

    $clientId = if ($ScenarioKey -eq $assessmentId) { $assessmentId } else { "$assessmentId`:$ScenarioKey" }
    $description = "Imported from Cymulate launched assessment '$assessmentId'"
    if ($ScenarioKey -ne $assessmentId) { $description += ", scenario '$ScenarioKey'" }
    $description += '.'
    if (-not [string]::IsNullOrWhiteSpace($detection)) { $description += " SIEM detection: $detection." }

    $metadata = New-Object 'System.Collections.Generic.List[object]'
    $metadata.Add(@{ key = 'Cymulate Assessment ID'; value = $assessmentId })
    $metadata.Add(@{ key = 'Cymulate Scenario Key'; value = $ScenarioKey })
    if (-not [string]::IsNullOrWhiteSpace($detection)) { $metadata.Add(@{ key = 'Cymulate SIEM Detection'; value = $detection }) }
    $metadata.Add(@{ key = 'Cymulate Technique MITRE ID'; value = $techniqueId })
    if (-not [string]::IsNullOrWhiteSpace($tactic.Id)) { $metadata.Add(@{ key = 'Cymulate Tactic MITRE ID'; value = $tactic.Id }) }

    $data = [ordered]@{
        clientId        = $clientId
        name            = Limit-Text $scenarioName 255
        description     = Limit-Text $description $MaxTextLength
        phase           = $phase
        technique       = $techniqueId
        organization    = $Organization
        status          = 'Completed'
        redTeamMetadata = @($metadata.ToArray())
        attackStart     = Get-EpochMilliseconds $startedAt
        attackStop      = Get-EpochMilliseconds $endedAt
    }
    if ($targets.Count -gt 0) { $data.targets = @($targets[0]) }

    if ($MapDetectionToOutcome -and -not [string]::IsNullOrWhiteSpace($detection)) {
        $normalized = $detection.Trim()
        if ($normalized -match '(?i)^(detected|true|yes|triggered|alerted|success)$') {
            $data.outcome = 'DETECTED'
        }
        elseif ($normalized -match '(?i)^(not[\s_-]*detected|false|no|missed|failed|undetected)$') {
            $data.outcome = 'NOTDETECTED'
        }
    }

    [pscustomobject]@{
        ScenarioId   = $clientId
        AssessmentId = $assessmentId
        Detection    = $detection
        TemplateName = $templateName
        TestCaseData = $data
    }
}

function Get-VectrPreflight {
    param(
        [Parameter(Mandatory = $true)] [string] $Uri,
        [Parameter(Mandatory = $true)] [string] $ApiKey,
        [Parameter(Mandatory = $true)] [string] $Database,
        [Parameter(Mandatory = $true)] [string] $CampaignId,
        [Parameter(Mandatory = $true)] [string] $Organization,
        [int] $TimeoutSec = 100,
        [bool] $SkipCertificateCheck = $false
    )

    $query = @'
query CymulateVectrPreflight($db: String!, $campaignId: String!, $organization: String!) {
  databases { name }
  campaign(db: $db, id: $campaignId) { id name }
  organizations(filter: { name: { eq: $organization } }, first: 2) { nodes { id name } }
}
'@
    $data = Invoke-VectrGraphQl -Uri $Uri -ApiKey $ApiKey -Query $query -Variables @{ db = $Database; campaignId = $CampaignId; organization = $Organization } -OperationName 'CymulateVectrPreflight' -TimeoutSec $TimeoutSec -SkipCertificateCheck $SkipCertificateCheck
    $databaseNames = @(Get-PropertyValue $data 'databases' @() | ForEach-Object { [string](Get-PropertyValue $_ 'name' '') })
    if ($databaseNames -inotcontains $Database) { throw "VECTR environment/database '$Database' was not found." }
    $campaign = Get-PropertyValue $data 'campaign'
    if ($null -eq $campaign) { throw "VECTR campaign '$CampaignId' was not found in environment '$Database'." }
    $organizations = @(Get-PropertyValue (Get-PropertyValue $data 'organizations') 'nodes' @())
    $organizationNames = @($organizations | ForEach-Object { [string](Get-PropertyValue $_ 'name' '') })
    if ($organizationNames -inotcontains $Organization) { throw "VECTR organization '$Organization' was not found." }

    [pscustomobject]@{
        Campaign = $campaign
    }
}

function New-VectrTestCases {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)] [string] $Uri,
        [Parameter(Mandatory = $true)] [string] $ApiKey,
        [Parameter(Mandatory = $true)] [string] $Database,
        [Parameter(Mandatory = $true)] [string] $CampaignId,
        [Parameter(Mandatory = $true)] [ValidateSet('MatchTemplateByName', 'WithoutTemplate')] [string] $MutationMode,
        [Parameter(Mandatory = $true)] [object[]] $Inputs,
        [int] $BatchSize = 25,
        [int] $TimeoutSec = 100,
        [bool] $SkipCertificateCheck = $false
    )

    $created = New-Object 'System.Collections.Generic.List[object]'
    for ($offset = 0; $offset -lt $Inputs.Count; $offset += $BatchSize) {
        $last = [Math]::Min($Inputs.Count - 1, $offset + $BatchSize - 1)
        $batch = @($Inputs[$offset..$last])
        if ($MutationMode -eq 'MatchTemplateByName') {
            $query = @'
mutation ImportCymulateTestCases($input: CreateTestCaseAndTemplateMatchByNameInput!) {
  testCase {
    createWithTemplateMatchByName(input: $input) {
      testCaseCreateItems { clientId testCase { id name } }
      testCases { id name }
    }
  }
}
'@
            $createInputs = New-Object 'System.Collections.Generic.List[object]'
            foreach ($item in $batch) {
                $createInputs.Add(@{ templateName = $item.TemplateName; testCaseData = $item.TestCaseData })
            }
            $mutationInput = @{
                db                         = $Database
                campaignId                 = $CampaignId
                suppressAutoTimelineEvents = $false
                createTestCaseInputs       = @($createInputs.ToArray())
            }
            $resultName = 'createWithTemplateMatchByName'
        }
        else {
            $query = @'
mutation ImportCymulateTestCases($input: CreateTestCaseWithoutTemplateInput!) {
  testCase {
    createWithoutTemplate(input: $input) {
      testCaseCreateItems { clientId testCase { id name } }
      testCases { id name }
    }
  }
}
'@
            $caseData = New-Object 'System.Collections.Generic.List[object]'
            foreach ($item in $batch) { $caseData.Add($item.TestCaseData) }
            $mutationInput = @{
                db                         = $Database
                campaignId                 = $CampaignId
                suppressAutoTimelineEvents = $false
                testCaseData               = @($caseData.ToArray())
            }
            $resultName = 'createWithoutTemplate'
        }

        Write-Verbose "Creating VECTR test-case batch containing $($batch.Count) item(s)."
        $data = Invoke-VectrGraphQl -Uri $Uri -ApiKey $ApiKey -Query $query -Variables @{ input = $mutationInput } -OperationName 'ImportCymulateTestCases' -TimeoutSec $TimeoutSec -SkipCertificateCheck $SkipCertificateCheck
        $testCaseRoot = Get-PropertyValue $data 'testCase'
        $payload = Get-PropertyValue $testCaseRoot $resultName
        $items = @(ConvertTo-ObjectArray (Get-PropertyValue $payload 'testCaseCreateItems' @()))
        if ($items.Count -eq 0) {
            $legacy = @(ConvertTo-ObjectArray (Get-PropertyValue $payload 'testCases' @()))
            if ($legacy.Count -ne $batch.Count) {
                throw "VECTR returned $($legacy.Count) creation result(s) for a batch of $($batch.Count)."
            }
            for ($i = 0; $i -lt $legacy.Count; $i++) {
                $legacyCase = $legacy[$i]
                $created.Add([pscustomobject]@{
                        ScenarioId = [string]$batch[$i].ScenarioId
                        Id         = [string](Get-PropertyValue $legacyCase 'id' '')
                        Name       = [string](Get-PropertyValue $legacyCase 'name' '')
                    })
            }
            continue
        }
        if ($items.Count -ne $batch.Count) {
            throw "VECTR returned $($items.Count) creation result(s) for a batch of $($batch.Count)."
        }
        foreach ($item in $items) {
            $testCase = Get-PropertyValue $item 'testCase'
            if ($null -eq $testCase) { throw "VECTR did not create the test case correlated by '$([string](Get-PropertyValue $item 'clientId' 'unknown'))'." }
            $created.Add([pscustomobject]@{
                    ScenarioId = [string](Get-PropertyValue $item 'clientId' '')
                    Id         = [string](Get-PropertyValue $testCase 'id' '')
                    Name       = [string](Get-PropertyValue $testCase 'name' '')
                })
        }
    }
    return @($created.ToArray())
}

function Convert-AssessmentFindingsToTestCases {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)] $Assessment,
        [Parameter(Mandatory = $true)] [AllowEmptyCollection()] [object[]] $Findings,
        [Parameter(Mandatory = $true)] [string] $Organization,
        [string[]] $SiemFindingNamePatterns,
        [int] $MaxTextLength = 8000,
        [bool] $MapDetectionToOutcome = $true,
        [bool] $RequireSiemFinding = $true
    )

    $assessmentId = Get-AssessmentId -Assessment $Assessment
    $inputs = New-Object 'System.Collections.Generic.List[object]'
    $skipped = New-Object 'System.Collections.Generic.List[string]'

    if ($Findings.Count -eq 0) {
        $skipped.Add("Assessment '$assessmentId' returned 0 findings.")
        return [pscustomobject]@{ Inputs = @(); Skipped = @($skipped.ToArray()); FindingsRead = 0; SiemMatched = 0 }
    }

    $siemFindings = @($Findings | Where-Object { Test-SiemAlertFindingName -FindingName (Get-FindingName -Finding $_) -Patterns $SiemFindingNamePatterns })
    $sourceFindings = $siemFindings
    if ($siemFindings.Count -eq 0) {
        if ($RequireSiemFinding) {
            $names = @($Findings | ForEach-Object { Get-FindingName -Finding $_ } | Where-Object { -not [string]::IsNullOrWhiteSpace($_) } | Select-Object -Unique)
            $skipped.Add("Assessment '$assessmentId' has no SIEM-alert finding. Finding names: $($names -join ', ').")
            return [pscustomobject]@{ Inputs = @(); Skipped = @($skipped.ToArray()); FindingsRead = $Findings.Count; SiemMatched = 0 }
        }
        $sourceFindings = @($Findings)
    }

    $groups = @($sourceFindings | Group-Object { Get-FindingScenarioKey -Finding $_ -AssessmentId $assessmentId })
    foreach ($group in $groups) {
        $siemFinding = @($group.Group)[0]
        try {
            $inputs.Add((ConvertTo-TestCaseInput -Assessment $Assessment -SiemFinding $siemFinding -Organization $Organization -ScenarioKey ([string]$group.Name) -MaxTextLength $MaxTextLength -MapDetectionToOutcome $MapDetectionToOutcome))
        }
        catch {
            $skipped.Add("Assessment '$assessmentId' scenario '$($group.Name)': $($_.Exception.Message)")
        }
    }

    return [pscustomobject]@{
        Inputs       = @($inputs.ToArray())
        Skipped      = @($skipped.ToArray())
        FindingsRead = $Findings.Count
        SiemMatched  = $siemFindings.Count
    }
}

function Invoke-CymulateVectrSync {
    [CmdletBinding(DefaultParameterSetName = 'SingleDate')]
    param(
        [Parameter(Mandatory = $true)] [string] $ConfigPath,
        [Parameter(ParameterSetName = 'SingleDate')] [datetime] $RunDate = (Get-Date),
        [Parameter(Mandatory = $true, ParameterSetName = 'DateRange')] [datetime] $StartDate,
        [Parameter(Mandatory = $true, ParameterSetName = 'DateRange')] [datetime] $EndDate,
        [bool] $DryRun = $false
    )

    if (-not (Test-Path -LiteralPath $ConfigPath -PathType Leaf)) { throw "Configuration file '$ConfigPath' was not found." }
    $config = Get-Content -Raw -LiteralPath $ConfigPath | ConvertFrom-Json
    $cymulate = Get-PropertyValue $config 'Cymulate'
    $vectr = Get-PropertyValue $config 'Vectr'
    $sync = Get-PropertyValue $config 'Sync' ([pscustomobject]@{})
    if ($null -eq $cymulate -or $null -eq $vectr) { throw "Configuration must contain 'Cymulate' and 'Vectr' objects." }

    $cymulateBaseUrl = Get-RequiredString $cymulate 'BaseUrl' 'Cymulate'
    $launchedAssessmentsPath = [string](Get-PropertyValue $cymulate 'LaunchedAssessmentsPath' '/v2/assessments/launched')
    if ([string]::IsNullOrWhiteSpace($launchedAssessmentsPath)) { throw 'Cymulate.LaunchedAssessmentsPath cannot be empty.' }
    $findingsPathTemplate = [string](Get-PropertyValue $cymulate 'FindingsPathTemplate' '')
    $cymulateToken = Get-EnvironmentSecret $cymulate 'TokenEnvironmentVariable' 'Cymulate'
    $vectrUri = Get-RequiredString $vectr 'GraphQlUrl' 'Vectr'
    $vectrApiKey = Get-EnvironmentSecret $vectr 'ApiKeyEnvironmentVariable' 'Vectr'
    $database = Get-RequiredString $vectr 'Database' 'Vectr'
    $campaignId = Get-RequiredString $vectr 'CampaignId' 'Vectr'
    $organization = Get-RequiredString $vectr 'Organization' 'Vectr'
    $mutationMode = [string](Get-PropertyValue $vectr 'MutationMode' 'MatchTemplateByName')
    if ($mutationMode -notin @('MatchTemplateByName', 'WithoutTemplate')) { throw "Vectr.MutationMode must be 'MatchTemplateByName' or 'WithoutTemplate'." }

    $timeZoneId = [string](Get-PropertyValue $sync 'TimeZoneId' '')
    $pageSize = [int](Get-PropertyValue $sync 'PageSize' 25)
    $maxPages = [int](Get-PropertyValue $sync 'MaxPages' 1000)
    $batchSize = [int](Get-PropertyValue $sync 'BatchSize' 25)
    $timeoutSec = [int](Get-PropertyValue $sync 'TimeoutSec' 100)
    $maxTextLength = [int](Get-PropertyValue $sync 'MaxTextLength' 8000)
    $mapDetectionToOutcome = ConvertTo-Boolean (Get-PropertyValue $sync 'MapDetectionToOutcome' $true) $true
    $requireSiemFinding = ConvertTo-Boolean (Get-PropertyValue $sync 'RequireSiemFinding' $true) $true
    $continueOnAssessmentError = ConvertTo-Boolean (Get-PropertyValue $sync 'ContinueOnAssessmentError' $true) $true
    $includePartiallyCompleted = ConvertTo-Boolean (Get-PropertyValue $sync 'IncludePartiallyCompleted' $false) $false
    $siemPatterns = @(ConvertTo-StringArray (Get-PropertyValue $sync 'SiemFindingNamePatterns' @('SIEM Alert triggered', '*SIEM*Alert*', '*SIEM*alert*')))
    if ($siemPatterns.Count -eq 0) { $siemPatterns = @('SIEM Alert triggered', '*SIEM*Alert*') }
    if ($pageSize -lt 1 -or $batchSize -lt 1 -or $timeoutSec -lt 1 -or $maxTextLength -lt 100 -or $maxPages -lt 1) {
        throw 'Sync numeric settings must be positive, and MaxTextLength must be at least 100.'
    }
    $skipCymulateCertificateCheck = ConvertTo-Boolean (Get-PropertyValue $cymulate 'SkipCertificateCheck' $false)
    $skipVectrCertificateCheck = ConvertTo-Boolean (Get-PropertyValue $vectr 'SkipCertificateCheck' $false)
    if ($PSCmdlet.ParameterSetName -eq 'DateRange') {
        $dateWindow = Get-DateWindow -StartDate $StartDate -EndDate $EndDate -TimeZoneId $timeZoneId
    }
    else {
        $dateWindow = Get-DateWindow -StartDate $RunDate -EndDate $RunDate -TimeZoneId $timeZoneId
    }
    Write-Verbose "Date range $($dateWindow.StartLocalDate) through $($dateWindow.EndLocalDate) in time zone '$($dateWindow.TimeZone.Id)' maps to UTC [$($dateWindow.StartUtc.ToString('o')), $($dateWindow.EndUtc.ToString('o')))."
    $preflight = Get-VectrPreflight -Uri $vectrUri -ApiKey $vectrApiKey -Database $database -CampaignId $campaignId -Organization $organization -TimeoutSec $timeoutSec -SkipCertificateCheck $skipVectrCertificateCheck
    $assessments = @(Get-CymulateAssessments -BaseUrl $cymulateBaseUrl -LaunchedAssessmentsPath $launchedAssessmentsPath -Token $cymulateToken -DateWindow $dateWindow -PageSize $pageSize -MaxPages $maxPages -TimeoutSec $timeoutSec -SkipCertificateCheck $skipCymulateCertificateCheck -IncludePartiallyCompleted $includePartiallyCompleted)

    $allInputs = New-Object 'System.Collections.Generic.List[object]'
    $skipped = New-Object 'System.Collections.Generic.List[string]'
    $findingsRead = 0
    $siemMatched = 0
    $assessmentsFailed = 0

    foreach ($assessment in $assessments) {
        $assessmentId = Get-AssessmentId -Assessment $assessment
        if ([string]::IsNullOrWhiteSpace($assessmentId)) {
            $message = 'A date-filtered launched assessment has no id.'
            if ($continueOnAssessmentError) { $skipped.Add($message); $assessmentsFailed++; continue }
            throw $message
        }

        try {
            Write-Verbose "Paging findings for filtered assessment '$assessmentId'."
            $findings = @(Get-CymulateFindings -BaseUrl $cymulateBaseUrl -LaunchedAssessmentsPath $launchedAssessmentsPath -Token $cymulateToken -AssessmentId $assessmentId -FindingsPathTemplate $findingsPathTemplate -PageSize $pageSize -MaxPages $maxPages -TimeoutSec $timeoutSec -SkipCertificateCheck $skipCymulateCertificateCheck)
            $converted = Convert-AssessmentFindingsToTestCases -Assessment $assessment -Findings $findings -Organization $organization -SiemFindingNamePatterns $siemPatterns -MaxTextLength $maxTextLength -MapDetectionToOutcome $mapDetectionToOutcome -RequireSiemFinding $requireSiemFinding
            $findingsRead += [int]$converted.FindingsRead
            $siemMatched += [int]$converted.SiemMatched
            foreach ($item in @($converted.Inputs)) { $allInputs.Add($item) }
            foreach ($item in @($converted.Skipped)) { $skipped.Add($item); Write-Warning $item }
        }
        catch {
            $assessmentsFailed++
            $message = "Assessment '$assessmentId' failed: $($_.Exception.Message)"
            if ($continueOnAssessmentError) {
                $skipped.Add($message)
                Write-Warning $message
                continue
            }
            throw
        }
    }

    $pending = @($allInputs.ToArray())
    $created = @()
    if (-not $DryRun -and $pending.Count -gt 0) {
        $created = @(New-VectrTestCases -Uri $vectrUri -ApiKey $vectrApiKey -Database $database -CampaignId $campaignId -MutationMode $mutationMode -Inputs $pending -BatchSize $batchSize -TimeoutSec $timeoutSec -SkipCertificateCheck $skipVectrCertificateCheck)
    }

    $summary = [pscustomobject]@{
        StartDate               = $dateWindow.StartLocalDate
        EndDate                 = $dateWindow.EndLocalDate
        TimeZone                = $dateWindow.TimeZone.Id
        AssessmentsMatched      = $assessments.Count
        AssessmentsFailed       = $assessmentsFailed
        FindingsRead            = $findingsRead
        SiemFindingsMatched     = $siemMatched
        TestCasesDerived        = $allInputs.Count
        TestCasesPending        = $pending.Count
        TestCasesCreated        = $created.Count
        SkippedCount            = $skipped.Count
        Skipped                 = @($skipped.ToArray())
        DryRun                  = $DryRun
        CampaignId              = $campaignId
        CampaignName            = [string](Get-PropertyValue $preflight.Campaign 'name' '')
    }
    Write-Output $summary
    if ($DryRun -and $pending.Count -gt 0) {
        Write-Verbose 'Dry run: the following test cases would be created:'
        foreach ($item in $pending) { Write-Verbose "  $($item.TestCaseData.name) [scenario $($item.ScenarioId)]" }
    }
    return @($created)
}

Export-ModuleMember -Function Invoke-CymulateVectrSync
