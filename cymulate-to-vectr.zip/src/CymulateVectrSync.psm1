Set-StrictMode -Version 2.0
$ErrorActionPreference = 'Stop'

$script:SyncMetadataKey = 'Cymulate Sync Key'

function Get-PropertyValue {
    param(
        $InputObject,
        [Parameter(Mandatory = $true)] [string] $Name,
        $Default = $null
    )

    if ($null -eq $InputObject) { return $Default }
    $property = $InputObject.PSObject.Properties[$Name]
    if ($null -eq $property -or $null -eq $property.Value) { return $Default }
    return $property.Value
}

function Get-RequiredString {
    param(
        [Parameter(Mandatory = $true)] $InputObject,
        [Parameter(Mandatory = $true)] [string] $Name,
        [Parameter(Mandatory = $true)] [string] $Context
    )

    $value = [string](Get-PropertyValue -InputObject $InputObject -Name $Name -Default '')
    if ([string]::IsNullOrWhiteSpace($value)) {
        throw "Missing required configuration value '$Context.$Name'."
    }
    return $value.Trim()
}

function Get-EnvironmentSecret {
    param(
        [Parameter(Mandatory = $true)] $Config,
        [Parameter(Mandatory = $true)] [string] $PropertyName,
        [Parameter(Mandatory = $true)] [string] $Context
    )

    $variableName = Get-RequiredString -InputObject $Config -Name $PropertyName -Context $Context
    $value = [Environment]::GetEnvironmentVariable($variableName)
    if ([string]::IsNullOrWhiteSpace($value)) {
        throw "Environment variable '$variableName', configured by '$Context.$PropertyName', is empty or undefined."
    }
    return $value
}

function ConvertTo-Boolean {
    param($Value, [bool] $Default = $false)
    if ($null -eq $Value) { return $Default }
    if ($Value -is [bool]) { return $Value }
    return [Convert]::ToBoolean($Value, [Globalization.CultureInfo]::InvariantCulture)
}

function ConvertTo-StringArray {
    param($Value)
    if ($null -eq $Value) { return @() }
    return @($Value | ForEach-Object { [string]$_ } | Where-Object { -not [string]::IsNullOrWhiteSpace($_) })
}

function Get-HttpStatusCode {
    param($ErrorRecord)
    try {
        if ($null -ne $ErrorRecord.Exception.Response.StatusCode) {
            return [int]$ErrorRecord.Exception.Response.StatusCode
        }
    }
    catch { }
    return 0
}

function Invoke-JsonRequest {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)] [ValidateSet('GET', 'POST')] [string] $Method,
        [Parameter(Mandatory = $true)] [string] $Uri,
        [Parameter(Mandatory = $true)] [hashtable] $Headers,
        $Body,
        [int] $MaxAttempts = 4,
        [int] $TimeoutSec = 100,
        [bool] $SkipCertificateCheck = $false
    )

    $restCommand = Get-Command Invoke-RestMethod
    if ($SkipCertificateCheck -and -not $restCommand.Parameters.ContainsKey('SkipCertificateCheck')) {
        throw 'SkipCertificateCheck requires PowerShell 7 or later. Use a trusted VECTR certificate or run this script with pwsh.'
    }

    for ($attempt = 1; $attempt -le $MaxAttempts; $attempt++) {
        $params = @{
            Method      = $Method
            Uri         = $Uri
            Headers     = $Headers
            TimeoutSec  = $TimeoutSec
            ErrorAction = 'Stop'
        }
        if ($null -ne $Body) {
            $params.ContentType = 'application/json'
            $params.Body = ($Body | ConvertTo-Json -Depth 40 -Compress)
        }
        if ($SkipCertificateCheck) { $params.SkipCertificateCheck = $true }

        try {
            return Invoke-RestMethod @params
        }
        catch {
            $statusCode = Get-HttpStatusCode -ErrorRecord $_
            $retryable = $statusCode -eq 0 -or $statusCode -eq 408 -or $statusCode -eq 429 -or $statusCode -ge 500
            if (-not $retryable -or $attempt -eq $MaxAttempts) {
                $detail = [string](Get-PropertyValue -InputObject $_ -Name 'ErrorDetails' -Default '')
                if ($detail.Length -gt 500) { $detail = $detail.Substring(0, 500) }
                throw "HTTP request failed ($statusCode) for $Method $Uri. $detail"
            }

            $delaySeconds = [Math]::Min(30, [Math]::Pow(2, $attempt - 1))
            Write-Verbose "Request failed with HTTP $statusCode. Retrying in $delaySeconds second(s) (attempt $attempt of $MaxAttempts)."
            Start-Sleep -Seconds $delaySeconds
        }
    }
}

function Invoke-VectrGraphQl {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)] [string] $Uri,
        [Parameter(Mandatory = $true)] [string] $ApiKey,
        [Parameter(Mandatory = $true)] [string] $Query,
        [Parameter(Mandatory = $true)] [hashtable] $Variables,
        [string] $OperationName,
        [int] $TimeoutSec = 100,
        [bool] $SkipCertificateCheck = $false
    )

    $body = @{ query = $Query; variables = $Variables }
    if (-not [string]::IsNullOrWhiteSpace($OperationName)) { $body.operationName = $OperationName }
    $headers = @{ Authorization = $ApiKey; Accept = 'application/json' }
    $response = Invoke-JsonRequest -Method POST -Uri $Uri -Headers $headers -Body $body -TimeoutSec $TimeoutSec -SkipCertificateCheck $SkipCertificateCheck

    $errors = @(Get-PropertyValue -InputObject $response -Name 'errors' -Default @())
    if ($errors.Count -gt 0) {
        $messages = @($errors | ForEach-Object { [string](Get-PropertyValue -InputObject $_ -Name 'message' -Default 'Unknown GraphQL error') })
        throw "VECTR GraphQL error: $($messages -join '; ')"
    }
    return Get-PropertyValue -InputObject $response -Name 'data'
}

function Get-DateWindow {
    param(
        [Parameter(Mandatory = $true)] [datetime] $StartDate,
        [Parameter(Mandatory = $true)] [datetime] $EndDate,
        [string] $TimeZoneId
    )

    if ($EndDate.Date -lt $StartDate.Date) {
        throw 'EndDate must be the same as or later than StartDate.'
    }

    $timeZone = if ([string]::IsNullOrWhiteSpace($TimeZoneId)) {
        [TimeZoneInfo]::Local
    }
    else {
        [TimeZoneInfo]::FindSystemTimeZoneById($TimeZoneId)
    }

    $startLocal = [DateTime]::SpecifyKind($StartDate.Date, [DateTimeKind]::Unspecified)
    # EndDate is inclusive for callers; the internal comparison interval is [start, end).
    $endLocal = [DateTime]::SpecifyKind($EndDate.Date.AddDays(1), [DateTimeKind]::Unspecified)
    [pscustomobject]@{
        TimeZone      = $timeZone
        StartUtc      = [TimeZoneInfo]::ConvertTimeToUtc($startLocal, $timeZone)
        EndUtc        = [TimeZoneInfo]::ConvertTimeToUtc($endLocal, $timeZone)
        StartLocalDate = $startLocal.ToString('yyyy-MM-dd', [Globalization.CultureInfo]::InvariantCulture)
        EndLocalDate   = $EndDate.Date.ToString('yyyy-MM-dd', [Globalization.CultureInfo]::InvariantCulture)
    }
}

function New-QueryString {
    param([Parameter(Mandatory = $true)] [hashtable] $Parameters)
    $parts = foreach ($key in ($Parameters.Keys | Sort-Object)) {
        $values = @($Parameters[$key])
        foreach ($value in $values) {
            if ($null -ne $value -and -not [string]::IsNullOrWhiteSpace([string]$value)) {
                '{0}={1}' -f [Uri]::EscapeDataString([string]$key), [Uri]::EscapeDataString([string]$value)
            }
        }
    }
    return $parts -join '&'
}

function Get-CymulateAssessments {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)] [string] $BaseUrl,
        [Parameter(Mandatory = $true)] [string] $LaunchedAssessmentsPath,
        [Parameter(Mandatory = $true)] [string] $Token,
        [Parameter(Mandatory = $true)] $DateWindow,
        [Parameter(Mandatory = $true)] [ValidateSet('CreatedAt', 'UpdatedAt')] [string] $DateField,
        [int] $PageSize = 100,
        [int] $TimeoutSec = 100,
        [bool] $SkipCertificateCheck = $false
    )

    $headers = @{ 'x-token' = $Token; Accept = 'application/json' }
    $page = 1
    $all = [Collections.Generic.List[object]]::new()
    do {
        $query = @{
            page      = $page
            limit     = $PageSize
            sortBy    = 'created'
            sortOrder = 'desc'
            status    = 'completed'
        }
        # Cymulate's fromDate/toDate filter is associated with the launched/created date.
        # Do not apply it when selecting by UpdatedAt, or assessments launched earlier but
        # completed on the run date could be missed.
        if ($DateField -eq 'CreatedAt') {
            $query.fromDate = $DateWindow.StartUtc.ToString('o', [Globalization.CultureInfo]::InvariantCulture)
            $query.toDate = $DateWindow.EndUtc.ToString('o', [Globalization.CultureInfo]::InvariantCulture)
        }

        $uri = '{0}{1}?{2}' -f $BaseUrl.TrimEnd('/'), ('/' + $LaunchedAssessmentsPath.Trim('/')), (New-QueryString -Parameters $query)
        Write-Verbose "Reading Cymulate launched assessments page $page."
        $response = Invoke-JsonRequest -Method GET -Uri $uri -Headers $headers -TimeoutSec $TimeoutSec -SkipCertificateCheck $SkipCertificateCheck
        $items = @(Get-PropertyValue -InputObject $response -Name 'data' -Default @())
        foreach ($item in $items) { $all.Add($item) }
        $count = [int](Get-PropertyValue -InputObject $response -Name 'count' -Default $all.Count)
        $page++
    } while ($items.Count -gt 0 -and $all.Count -lt $count)

    $selected = foreach ($assessment in $all) {
        if ([string](Get-PropertyValue -InputObject $assessment -Name 'status' -Default '') -ine 'Completed') { continue }
        $dateText = [string](Get-PropertyValue -InputObject $assessment -Name $DateField -Default '')
        if ([string]::IsNullOrWhiteSpace($dateText)) {
            Write-Warning "Assessment '$([string](Get-PropertyValue $assessment 'id' 'unknown'))' has no $DateField value and was skipped."
            continue
        }
        $dateValue = [DateTimeOffset]::Parse($dateText, [Globalization.CultureInfo]::InvariantCulture, [Globalization.DateTimeStyles]::AssumeUniversal)
        if ($dateValue.UtcDateTime -ge $DateWindow.StartUtc -and $dateValue.UtcDateTime -lt $DateWindow.EndUtc) {
            $assessment
        }
    }
    return @($selected)
}

function Get-CymulateFindings {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)] [string] $BaseUrl,
        [Parameter(Mandatory = $true)] [string] $LaunchedAssessmentsPath,
        [Parameter(Mandatory = $true)] [string] $Token,
        [Parameter(Mandatory = $true)] [string] $ScenarioId,
        [int] $PageSize = 100,
        [int] $TimeoutSec = 100,
        [bool] $SkipCertificateCheck = $false
    )

    $headers = @{ 'x-token' = $Token; Accept = 'application/json' }
    $page = 1
    $cursor = ''
    $all = [Collections.Generic.List[object]]::new()
    do {
        $queryParams = @{ page = $page; limit = $PageSize }
        if (-not [string]::IsNullOrWhiteSpace($cursor)) { $queryParams.cursor = $cursor }
        $query = New-QueryString -Parameters $queryParams
        $encodedId = [Uri]::EscapeDataString($ScenarioId)
        $uri = '{0}{1}/{2}/findings?{3}' -f $BaseUrl.TrimEnd('/'), ('/' + $LaunchedAssessmentsPath.Trim('/')), $encodedId, $query
        Write-Verbose "Reading Cymulate findings for launched scenario $ScenarioId, page $page."
        $response = Invoke-JsonRequest -Method GET -Uri $uri -Headers $headers -TimeoutSec $TimeoutSec -SkipCertificateCheck $SkipCertificateCheck
        $items = @(Get-PropertyValue -InputObject $response -Name 'findings' -Default @())
        foreach ($item in $items) { $all.Add($item) }
        $count = [int](Get-PropertyValue -InputObject $response -Name 'count' -Default $all.Count)
        $nextCursor = [string](Get-PropertyValue -InputObject $response -Name 'nextCursor' -Default '')
        $cursor = $nextCursor
        $page++
    } while ($items.Count -gt 0 -and $all.Count -lt $count)
    return @($all)
}

function Get-EpochMilliseconds {
    param([string] $DateText)
    if ([string]::IsNullOrWhiteSpace($DateText)) { return $null }
    return [double]([DateTimeOffset]::Parse($DateText, [Globalization.CultureInfo]::InvariantCulture, [Globalization.DateTimeStyles]::AssumeUniversal).ToUnixTimeMilliseconds())
}

function Limit-Text {
    param([string] $Text, [int] $MaxLength)
    if ($null -eq $Text) { return '' }
    if ($Text.Length -le $MaxLength) { return $Text }
    return $Text.Substring(0, [Math]::Max(0, $MaxLength - 16)) + "`n[truncated]"
}

function Get-RequiredArrayMitreId {
    param(
        [Parameter(Mandatory = $true)] $Finding,
        [Parameter(Mandatory = $true)] [string] $PropertyName,
        [Parameter(Mandatory = $true)] [string] $ScenarioId
    )

    $values = @(Get-PropertyValue $Finding $PropertyName @())
    if ($values.Count -eq 0) {
        throw "The 'SIEM Alert triggered' finding for scenario '$ScenarioId' has no $PropertyName entries."
    }
    $mitreId = [string](Get-PropertyValue $values[0] 'mitreID' '')
    if ([string]::IsNullOrWhiteSpace($mitreId)) {
        throw "The first $PropertyName entry for scenario '$ScenarioId' has no mitreID value."
    }
    return $mitreId
}

function Get-SiemAlertFinding {
    param(
        [Parameter(Mandatory = $true)] [AllowEmptyCollection()] [object[]] $Findings,
        [Parameter(Mandatory = $true)] [string] $ScenarioId
    )

    if ($Findings.Count -lt 3) {
        throw "Launched scenario '$ScenarioId' returned $($Findings.Count) finding(s); at least 3 are required."
    }

    $matches = @($Findings | Where-Object {
        [string](Get-PropertyValue $_ 'findingName' '') -ceq 'SIEM Alert triggered'
    })
    if ($matches.Count -eq 0) {
        throw "Launched scenario '$ScenarioId' has no finding whose findingName is exactly 'SIEM Alert triggered'."
    }
    if ($matches.Count -gt 1) {
        Write-Warning "Launched scenario '$ScenarioId' has $($matches.Count) 'SIEM Alert triggered' findings; the first one will be used."
    }
    return $matches[0]
}

function ConvertTo-TestCaseInput {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)] $Scenario,
        [Parameter(Mandatory = $true)] $SiemFinding,
        [Parameter(Mandatory = $true)] [string] $Organization,
        [int] $MaxTextLength = 8000
    )

    $scenarioId = [string](Get-PropertyValue $Scenario 'id' '')
    $scenarioName = [string](Get-PropertyValue $Scenario 'name' '')
    if ([string]::IsNullOrWhiteSpace($scenarioId)) { throw 'A date-filtered launched scenario has no id.' }
    if ([string]::IsNullOrWhiteSpace($scenarioName)) { throw "Launched scenario '$scenarioId' has no name." }

    $startedAt = [string](Get-PropertyValue $Scenario 'startedAt' '')
    $endedAt = [string](Get-PropertyValue $Scenario 'endedAt' '')
    if ([string]::IsNullOrWhiteSpace($startedAt)) { throw "Launched scenario '$scenarioId' has no startedAt value." }
    if ([string]::IsNullOrWhiteSpace($endedAt)) { throw "Launched scenario '$scenarioId' has no endedAt value." }

    $targets = @(ConvertTo-StringArray (Get-PropertyValue $Scenario 'targets' @()))
    if ($targets.Count -eq 0) { throw "Launched scenario '$scenarioId' has no targets." }
    $targetParts = @($targets[0] -split '\s+' | Where-Object { -not [string]::IsNullOrWhiteSpace($_) })
    if ($targetParts.Count -eq 0) { throw "The first target for launched scenario '$scenarioId' is empty." }

    $techniqueMitreId = Get-RequiredArrayMitreId -Finding $SiemFinding -PropertyName 'techniques' -ScenarioId $scenarioId
    $tacticMitreId = Get-RequiredArrayMitreId -Finding $SiemFinding -PropertyName 'tactics' -ScenarioId $scenarioId
    $detection = [string](Get-PropertyValue $SiemFinding 'detection' '')
    $templateId = [string](Get-PropertyValue $Scenario 'templateId' '')
    $templateName = if ([string]::IsNullOrWhiteSpace($templateId)) { "Cymulate $scenarioName" } else { "Cymulate $templateId" }

    $metadata = @(
        @{ key = $script:SyncMetadataKey; value = $scenarioId }
        @{ key = 'Cymulate Scenario ID'; value = $scenarioId }
        @{ key = 'Cymulate SIEM Detection'; value = $detection }
        @{ key = 'Cymulate Technique MITRE ID'; value = $techniqueMitreId }
        @{ key = 'Cymulate Tactic MITRE ID'; value = $tacticMitreId }
    ) | Where-Object { -not [string]::IsNullOrWhiteSpace([string]$_.value) }

    $data = [ordered]@{
        clientId       = $scenarioId
        name           = Limit-Text $scenarioName 255
        description    = Limit-Text "Imported from Cymulate launched scenario '$scenarioId'." $MaxTextLength
        phase          = $tacticMitreId
        technique      = $techniqueMitreId
        organization   = $Organization
        status         = 'Completed'
        targets        = @($targetParts[0])
        redTeamMetadata = @($metadata)
        attackStart    = Get-EpochMilliseconds $startedAt
        attackStop     = Get-EpochMilliseconds $endedAt
    }

    # Outcome fields are intentionally omitted until the Cymulate detection-to-VECTR
    # outcome mapping is supplied.
    [pscustomobject]@{
        SyncKey      = $scenarioId
        Detection    = $detection
        TemplateName = $templateName
        TestCaseData = $data
    }
}

function Get-VectrPreflight {
    param(
        [Parameter(Mandatory = $true)] [string] $Uri,
        [Parameter(Mandatory = $true)] [string] $ApiKey,
        [Parameter(Mandatory = $true)] [string] $Database,
        [Parameter(Mandatory = $true)] [string] $CampaignId,
        [Parameter(Mandatory = $true)] [string] $Organization,
        [int] $TimeoutSec = 100,
        [bool] $SkipCertificateCheck = $false
    )

    $query = @'
query CymulateVectrPreflight($db: String!, $campaignId: String!, $organization: String!) {
  databases { id name }
  campaign(db: $db, id: $campaignId) { id name }
  organizations(filter: { name: { eq: $organization } }, first: 2) { nodes { id name } }
}
'@
    $data = Invoke-VectrGraphQl -Uri $Uri -ApiKey $ApiKey -Query $query -Variables @{ db = $Database; campaignId = $CampaignId; organization = $Organization } -OperationName 'CymulateVectrPreflight' -TimeoutSec $TimeoutSec -SkipCertificateCheck $SkipCertificateCheck
    $databaseNames = @(Get-PropertyValue $data 'databases' @() | ForEach-Object { [string](Get-PropertyValue $_ 'name' '') })
    if ($databaseNames -inotcontains $Database) { throw "VECTR environment/database '$Database' was not found." }
    $campaign = Get-PropertyValue $data 'campaign'
    if ($null -eq $campaign) { throw "VECTR campaign '$CampaignId' was not found in environment '$Database'." }
    $organizations = @(Get-PropertyValue (Get-PropertyValue $data 'organizations') 'nodes' @())
    $organizationNames = @($organizations | ForEach-Object { [string](Get-PropertyValue $_ 'name' '') })
    if ($organizationNames -inotcontains $Organization) { throw "VECTR organization '$Organization' was not found." }

    [pscustomobject]@{
        Campaign = $campaign
    }
}

function Get-ExistingVectrSyncKeys {
    param(
        [Parameter(Mandatory = $true)] [string] $Uri,
        [Parameter(Mandatory = $true)] [string] $ApiKey,
        [Parameter(Mandatory = $true)] [string] $Database,
        [int] $TimeoutSec = 100,
        [bool] $SkipCertificateCheck = $false
    )

    $query = @'
query CymulateImportedTestCases($db: String!, $first: Int!, $after: String) {
  testcases(db: $db, filter: { metadata: { key: "Cymulate Sync Key" } }, first: $first, after: $after) {
    nodes { id name metadata { key value } }
    pageInfo { endCursor hasNextPage }
  }
}
'@
    $keys = [Collections.Generic.HashSet[string]]::new([StringComparer]::OrdinalIgnoreCase)
    $after = $null
    do {
        $data = Invoke-VectrGraphQl -Uri $Uri -ApiKey $ApiKey -Query $query -Variables @{ db = $Database; first = 250; after = $after } -OperationName 'CymulateImportedTestCases' -TimeoutSec $TimeoutSec -SkipCertificateCheck $SkipCertificateCheck
        $connection = Get-PropertyValue $data 'testcases'
        foreach ($node in @(Get-PropertyValue $connection 'nodes' @())) {
            foreach ($metadata in @(Get-PropertyValue $node 'metadata' @())) {
                if ([string](Get-PropertyValue $metadata 'key' '') -ieq $script:SyncMetadataKey) {
                    [void]$keys.Add([string](Get-PropertyValue $metadata 'value' ''))
                }
            }
        }
        $pageInfo = Get-PropertyValue $connection 'pageInfo'
        $hasNext = ConvertTo-Boolean (Get-PropertyValue $pageInfo 'hasNextPage' $false)
        $after = [string](Get-PropertyValue $pageInfo 'endCursor' '')
    } while ($hasNext -and -not [string]::IsNullOrWhiteSpace($after))
    # HashSet implements IEnumerable; prevent PowerShell from unrolling it so callers
    # retain the O(1) Contains operation, including when the set is empty.
    Write-Output -NoEnumerate $keys
}

function New-VectrTestCases {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)] [string] $Uri,
        [Parameter(Mandatory = $true)] [string] $ApiKey,
        [Parameter(Mandatory = $true)] [string] $Database,
        [Parameter(Mandatory = $true)] [string] $CampaignId,
        [Parameter(Mandatory = $true)] [ValidateSet('MatchTemplateByName', 'WithoutTemplate')] [string] $MutationMode,
        [Parameter(Mandatory = $true)] [object[]] $Inputs,
        [int] $BatchSize = 25,
        [int] $TimeoutSec = 100,
        [bool] $SkipCertificateCheck = $false
    )

    $created = [Collections.Generic.List[object]]::new()
    for ($offset = 0; $offset -lt $Inputs.Count; $offset += $BatchSize) {
        $last = [Math]::Min($Inputs.Count - 1, $offset + $BatchSize - 1)
        $batch = @($Inputs[$offset..$last])
        if ($MutationMode -eq 'MatchTemplateByName') {
            $query = @'
mutation ImportCymulateTestCases($input: CreateTestCaseAndTemplateMatchByNameInput!) {
  testCase {
    createWithTemplateMatchByName(input: $input) {
      testCaseCreateItems { clientId testCase { id name } }
    }
  }
}
'@
            $mutationInput = @{
                db = $Database
                campaignId = $CampaignId
                suppressAutoTimelineEvents = $false
                createTestCaseInputs = @($batch | ForEach-Object { @{ templateName = $_.TemplateName; testCaseData = $_.TestCaseData } })
            }
            $resultName = 'createWithTemplateMatchByName'
        }
        else {
            $query = @'
mutation ImportCymulateTestCases($input: CreateTestCaseWithoutTemplateInput!) {
  testCase {
    createWithoutTemplate(input: $input) {
      testCaseCreateItems { clientId testCase { id name } }
    }
  }
}
'@
            $mutationInput = @{
                db = $Database
                campaignId = $CampaignId
                suppressAutoTimelineEvents = $false
                testCaseData = @($batch | ForEach-Object { $_.TestCaseData })
            }
            $resultName = 'createWithoutTemplate'
        }

        Write-Verbose "Creating VECTR test-case batch containing $($batch.Count) item(s)."
        $data = Invoke-VectrGraphQl -Uri $Uri -ApiKey $ApiKey -Query $query -Variables @{ input = $mutationInput } -OperationName 'ImportCymulateTestCases' -TimeoutSec $TimeoutSec -SkipCertificateCheck $SkipCertificateCheck
        $testCaseRoot = Get-PropertyValue $data 'testCase'
        $payload = Get-PropertyValue $testCaseRoot $resultName
        $items = @(Get-PropertyValue $payload 'testCaseCreateItems' @())
        if ($items.Count -ne $batch.Count) {
            throw "VECTR returned $($items.Count) creation result(s) for a batch of $($batch.Count)."
        }
        foreach ($item in $items) {
            $testCase = Get-PropertyValue $item 'testCase'
            if ($null -eq $testCase) { throw "VECTR did not create the test case correlated by '$([string](Get-PropertyValue $item 'clientId' 'unknown'))'." }
            $created.Add([pscustomobject]@{
                SyncKey = [string](Get-PropertyValue $item 'clientId' '')
                Id      = [string](Get-PropertyValue $testCase 'id' '')
                Name    = [string](Get-PropertyValue $testCase 'name' '')
            })
        }
    }
    return @($created)
}

function Invoke-CymulateVectrSync {
    [CmdletBinding(DefaultParameterSetName = 'SingleDate')]
    param(
        [Parameter(Mandatory = $true)] [string] $ConfigPath,
        [Parameter(ParameterSetName = 'SingleDate')] [datetime] $RunDate = (Get-Date),
        [Parameter(Mandatory = $true, ParameterSetName = 'DateRange')] [datetime] $StartDate,
        [Parameter(Mandatory = $true, ParameterSetName = 'DateRange')] [datetime] $EndDate,
        [bool] $DryRun = $false
    )

    if (-not (Test-Path -LiteralPath $ConfigPath -PathType Leaf)) { throw "Configuration file '$ConfigPath' was not found." }
    $config = Get-Content -Raw -LiteralPath $ConfigPath | ConvertFrom-Json
    $cymulate = Get-PropertyValue $config 'Cymulate'
    $vectr = Get-PropertyValue $config 'Vectr'
    $sync = Get-PropertyValue $config 'Sync' ([pscustomobject]@{})
    if ($null -eq $cymulate -or $null -eq $vectr) { throw "Configuration must contain 'Cymulate' and 'Vectr' objects." }

    $cymulateBaseUrl = Get-RequiredString $cymulate 'BaseUrl' 'Cymulate'
    $launchedAssessmentsPath = [string](Get-PropertyValue $cymulate 'LaunchedAssessmentsPath' '/launched-assessments')
    if ([string]::IsNullOrWhiteSpace($launchedAssessmentsPath)) { throw "Cymulate.LaunchedAssessmentsPath cannot be empty." }
    $cymulateToken = Get-EnvironmentSecret $cymulate 'TokenEnvironmentVariable' 'Cymulate'
    $vectrUri = Get-RequiredString $vectr 'GraphQlUrl' 'Vectr'
    $vectrApiKey = Get-EnvironmentSecret $vectr 'ApiKeyEnvironmentVariable' 'Vectr'
    $database = Get-RequiredString $vectr 'Database' 'Vectr'
    $campaignId = Get-RequiredString $vectr 'CampaignId' 'Vectr'
    $organization = Get-RequiredString $vectr 'Organization' 'Vectr'
    $mutationMode = [string](Get-PropertyValue $vectr 'MutationMode' 'MatchTemplateByName')
    if ($mutationMode -notin @('MatchTemplateByName', 'WithoutTemplate')) { throw "Vectr.MutationMode must be 'MatchTemplateByName' or 'WithoutTemplate'." }

    $dateField = [string](Get-PropertyValue $sync 'DateField' 'UpdatedAt')
    if ($dateField -notin @('CreatedAt', 'UpdatedAt')) { throw "Sync.DateField must be 'CreatedAt' or 'UpdatedAt'." }
    $timeZoneId = [string](Get-PropertyValue $sync 'TimeZoneId' '')
    $pageSize = [int](Get-PropertyValue $sync 'PageSize' 100)
    $batchSize = [int](Get-PropertyValue $sync 'BatchSize' 25)
    $timeoutSec = [int](Get-PropertyValue $sync 'TimeoutSec' 100)
    $maxTextLength = [int](Get-PropertyValue $sync 'MaxTextLength' 8000)
    if ($pageSize -lt 1 -or $batchSize -lt 1 -or $timeoutSec -lt 1 -or $maxTextLength -lt 100) { throw 'Sync numeric settings must be positive, and MaxTextLength must be at least 100.' }
    $skipCymulateCertificateCheck = ConvertTo-Boolean (Get-PropertyValue $cymulate 'SkipCertificateCheck' $false)
    $skipVectrCertificateCheck = ConvertTo-Boolean (Get-PropertyValue $vectr 'SkipCertificateCheck' $false)
    if ($PSCmdlet.ParameterSetName -eq 'DateRange') {
        $dateWindow = Get-DateWindow -StartDate $StartDate -EndDate $EndDate -TimeZoneId $timeZoneId
    }
    else {
        $dateWindow = Get-DateWindow -StartDate $RunDate -EndDate $RunDate -TimeZoneId $timeZoneId
    }
    Write-Verbose "Date range $($dateWindow.StartLocalDate) through $($dateWindow.EndLocalDate) in time zone '$($dateWindow.TimeZone.Id)' maps to UTC [$($dateWindow.StartUtc.ToString('o')), $($dateWindow.EndUtc.ToString('o')))."
    $preflight = Get-VectrPreflight -Uri $vectrUri -ApiKey $vectrApiKey -Database $database -CampaignId $campaignId -Organization $organization -TimeoutSec $timeoutSec -SkipCertificateCheck $skipVectrCertificateCheck
    $existingKeys = Get-ExistingVectrSyncKeys -Uri $vectrUri -ApiKey $vectrApiKey -Database $database -TimeoutSec $timeoutSec -SkipCertificateCheck $skipVectrCertificateCheck
    $scenarios = @(Get-CymulateAssessments -BaseUrl $cymulateBaseUrl -LaunchedAssessmentsPath $launchedAssessmentsPath -Token $cymulateToken -DateWindow $dateWindow -DateField $dateField -PageSize $pageSize -TimeoutSec $timeoutSec -SkipCertificateCheck $skipCymulateCertificateCheck)

    $allInputs = [Collections.Generic.List[object]]::new()
    $findingsRead = 0
    foreach ($scenario in $scenarios) {
        $scenarioId = [string](Get-PropertyValue $scenario 'id' '')
        if ([string]::IsNullOrWhiteSpace($scenarioId)) { throw 'A date-filtered launched scenario has no id.' }

        $findings = @(Get-CymulateFindings -BaseUrl $cymulateBaseUrl -LaunchedAssessmentsPath $launchedAssessmentsPath -Token $cymulateToken -ScenarioId $scenarioId -PageSize $pageSize -TimeoutSec $timeoutSec -SkipCertificateCheck $skipCymulateCertificateCheck)
        $findingsRead += $findings.Count
        $siemFinding = Get-SiemAlertFinding -Findings $findings -ScenarioId $scenarioId
        $allInputs.Add((ConvertTo-TestCaseInput -Scenario $scenario -SiemFinding $siemFinding -Organization $organization -MaxTextLength $maxTextLength))
    }

    $pending = @($allInputs | Where-Object { -not $existingKeys.Contains($_.SyncKey) })
    $skippedExisting = $allInputs.Count - $pending.Count
    $created = @()
    if (-not $DryRun -and $pending.Count -gt 0) {
        $created = @(New-VectrTestCases -Uri $vectrUri -ApiKey $vectrApiKey -Database $database -CampaignId $campaignId -MutationMode $mutationMode -Inputs $pending -BatchSize $batchSize -TimeoutSec $timeoutSec -SkipCertificateCheck $skipVectrCertificateCheck)
    }

    $summary = [pscustomobject]@{
        StartDate                 = $dateWindow.StartLocalDate
        EndDate                   = $dateWindow.EndLocalDate
        TimeZone                  = $dateWindow.TimeZone.Id
        DateField                 = $dateField
        ScenariosMatched          = $scenarios.Count
        FindingsRead              = $findingsRead
        SiemFindingsMatched       = $allInputs.Count
        TestCasesDerived          = $allInputs.Count
        ExistingTestCasesSkipped  = $skippedExisting
        TestCasesPending          = $pending.Count
        TestCasesCreated          = $created.Count
        DryRun                    = $DryRun
        CampaignId                = $campaignId
        CampaignName              = [string](Get-PropertyValue $preflight.Campaign 'name' '')
    }
    Write-Output $summary
    if ($DryRun -and $pending.Count -gt 0) {
        Write-Verbose 'Dry run: the following test cases would be created:'
        foreach ($item in $pending) { Write-Verbose "  $($item.TestCaseData.name) [$($item.SyncKey)]" }
    }
    return @($created)
}

Export-ModuleMember -Function Invoke-CymulateVectrSync
