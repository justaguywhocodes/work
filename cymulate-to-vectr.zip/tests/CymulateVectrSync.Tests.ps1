Import-Module (Join-Path $PSScriptRoot '..\src\CymulateVectrSync.psm1') -Force

Describe 'CymulateVectrSync transformations' {
    InModuleScope CymulateVectrSync {
        It 'converts a local calendar day to a half-open UTC interval' {
            $window = Get-DateWindow -StartDate ([datetime]'2026-08-28') -EndDate ([datetime]'2026-08-28') -TimeZoneId 'Eastern Standard Time'
            $window.StartUtc.ToString('o') | Should Be '2026-08-28T04:00:00.0000000Z'
            $window.EndUtc.ToString('o') | Should Be '2026-08-29T04:00:00.0000000Z'
        }

        It 'treats the range end date as inclusive' {
            $window = Get-DateWindow -StartDate ([datetime]'2026-08-27') -EndDate ([datetime]'2026-08-28') -TimeZoneId 'Eastern Standard Time'
            $window.StartLocalDate | Should Be '2026-08-27'
            $window.EndLocalDate | Should Be '2026-08-28'
            $window.StartUtc.ToString('o') | Should Be '2026-08-27T04:00:00.0000000Z'
            $window.EndUtc.ToString('o') | Should Be '2026-08-29T04:00:00.0000000Z'
        }

        It 'rejects a range whose end precedes its start' {
            $threw = $false
            try {
                Get-DateWindow -StartDate ([datetime]'2026-08-28') -EndDate ([datetime]'2026-08-27')
            }
            catch {
                $threw = $true
            }
            $threw | Should Be $true
        }

        It 'GETs launched assessments and filters completed scenarios to the date window' {
            Mock Invoke-JsonRequest {
                [pscustomobject]@{
                    count = 2
                    data = @(
                        [pscustomobject]@{ id = 'inside'; status = 'Completed'; updatedAt = '2026-08-28T12:00:00Z' },
                        [pscustomobject]@{ id = 'outside'; status = 'Completed'; updatedAt = '2026-08-29T12:00:00Z' }
                    )
                }
            }
            $window = Get-DateWindow -StartDate ([datetime]'2026-08-28') -EndDate ([datetime]'2026-08-28') -TimeZoneId 'UTC'

            $items = @(Get-CymulateAssessments -BaseUrl 'https://cymulate.example' -LaunchedAssessmentsPath '/launched-assessments' -Token 'test' -DateWindow $window -DateField UpdatedAt)

            $items.Count | Should Be 1
            $items[0].id | Should Be 'inside'
            Assert-MockCalled Invoke-JsonRequest 1 -ParameterFilter {
                $Method -eq 'GET' -and $Uri -like 'https://cymulate.example/launched-assessments?*'
            }
        }

        It 'GETs the findings endpoint for the scenario id' {
            Mock Invoke-JsonRequest {
                [pscustomobject]@{
                    count = 3
                    findings = @(
                        [pscustomobject]@{ findingName = 'One' },
                        [pscustomobject]@{ findingName = 'Two' },
                        [pscustomobject]@{ findingName = 'SIEM Alert triggered' }
                    )
                }
            }

            $findings = @(Get-CymulateFindings -BaseUrl 'https://cymulate.example' -LaunchedAssessmentsPath '/launched-assessments' -Token 'test' -ScenarioId 'scenario/a')

            $findings.Count | Should Be 3
            Assert-MockCalled Invoke-JsonRequest 1 -ParameterFilter {
                $Method -eq 'GET' -and $Uri -like 'https://cymulate.example/launched-assessments/scenario%2Fa/findings?*'
            }
        }

        It 'requires at least three findings for a scenario' {
            $threw = $false
            try {
                Get-SiemAlertFinding -ScenarioId 'scenario-1' -Findings @(
                    [pscustomobject]@{ findingName = 'First' },
                    [pscustomobject]@{ findingName = 'SIEM Alert triggered' }
                )
            }
            catch {
                $threw = $true
                $_.Exception.Message | Should Match 'at least 3'
            }
            $threw | Should Be $true
        }

        It 'selects the SIEM Alert triggered finding by exact name' {
            $match = Get-SiemAlertFinding -ScenarioId 'scenario-1' -Findings @(
                [pscustomobject]@{ findingName = 'Other finding'; detection = 'No' },
                [pscustomobject]@{ findingName = 'SIEM Alert Triggered'; detection = 'Wrong case' },
                [pscustomobject]@{ findingName = 'SIEM Alert triggered'; detection = 'Detected' }
            )
            $match.detection | Should Be 'Detected'
        }

        It 'maps one launched scenario and its SIEM finding to one VECTR input' {
            $scenario = [pscustomobject]@{
                id = 'scenario-1'; name = 'PowerShell'; templateId = 'template-1'
                startedAt = '2026-08-28T12:00:00Z'; endedAt = '2026-08-28T12:05:00Z'
                targets = @('host-a DOMAIN\user', 'host-b')
            }
            $finding = [pscustomobject]@{
                findingName = 'SIEM Alert triggered'; detection = 'Detected by Splunk'
                techniques = @(
                    [pscustomobject]@{ mitreID = 'T1059.001' },
                    [pscustomobject]@{ mitreID = 'T1105' }
                )
                tactics = @(
                    [pscustomobject]@{ mitreID = 'TA0002' },
                    [pscustomobject]@{ mitreID = 'TA0005' }
                )
            }

            $item = ConvertTo-TestCaseInput -Scenario $scenario -SiemFinding $finding -Organization 'ACME'

            $item.ScenarioId | Should Be 'scenario-1'
            $item.TestCaseData.name | Should Be 'PowerShell'
            @($item.TestCaseData.targets).Count | Should Be 1
            $item.TestCaseData.targets[0] | Should Be 'host-a'
            $item.TestCaseData.technique | Should Be 'T1059.001'
            $item.TestCaseData.phase | Should Be 'TA0002'
            $item.TestCaseData.attackStart | Should Be 1787918400000
            $item.TestCaseData.attackStop | Should Be 1787918700000
            $item.TestCaseData.Contains('attackSuccess') | Should Be $false
            $item.TestCaseData.Contains('outcome') | Should Be $false
            @($item.TestCaseData.redTeamMetadata | Where-Object key -eq 'Cymulate SIEM Detection').value | Should Be 'Detected by Splunk'
            @($item.TestCaseData.redTeamMetadata | Where-Object key -eq 'Cymulate Sync Key').Count | Should Be 0
        }
    }
}
