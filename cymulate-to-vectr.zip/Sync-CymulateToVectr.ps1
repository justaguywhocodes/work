[CmdletBinding(SupportsShouldProcess = $true, DefaultParameterSetName = 'SingleDate')]
param(
    [Parameter()]
    [string] $ConfigPath = (Join-Path $PSScriptRoot 'config.json'),

    [Parameter(ParameterSetName = 'SingleDate')]
    [datetime] $RunDate = (Get-Date),

    [Parameter(Mandatory = $true, ParameterSetName = 'DateRange')]
    [datetime] $StartDate,

    [Parameter(Mandatory = $true, ParameterSetName = 'DateRange')]
    [datetime] $EndDate,

    [Parameter()]
    [switch] $DryRun
)

Set-StrictMode -Version 2.0
$ErrorActionPreference = 'Stop'

$modulePath = Join-Path $PSScriptRoot 'src\CymulateVectrSync.psm1'
Import-Module $modulePath -Force

$invokeParams = @{
    ConfigPath = $ConfigPath
    DryRun    = [bool]($DryRun -or $WhatIfPreference)
    Verbose   = ($VerbosePreference -eq 'Continue')
}
if ($PSCmdlet.ParameterSetName -eq 'DateRange') {
    $invokeParams.StartDate = $StartDate
    $invokeParams.EndDate = $EndDate
}
else {
    $invokeParams.RunDate = $RunDate
}

Invoke-CymulateVectrSync @invokeParams
