# Cymulate to VECTR sync

`Sync-CymulateToVectr.ps1` imports completed Cymulate launched assessments into an existing VECTR campaign. It reads the launched-assessments endpoint, filters the returned scenarios to the requested date range, retrieves each scenario's findings, and creates one VECTR test case per qualifying scenario.

## Requirements

- PowerShell 7 is recommended. Windows PowerShell 5.1 works when both API certificates are trusted.
- A Cymulate API token with access to launched assessments and findings.
- A VECTR API key with query and test-case creation permissions.
- An existing VECTR environment, campaign, and organization.

VECTR uses a single GraphQL endpoint: `https://<vectr-host>/sra-purpletools-rest/graphql`. The API key environment variable must contain the complete authorization value, including the `VEC1` prefix.

## Configure

Copy `config.example.json` to `config.json` and update the non-secret values:

```powershell
Copy-Item .\config.example.json .\config.json
$env:CYMULATE_API_TOKEN = '<Cymulate x-token value>'
$env:VECTR_API_KEY = 'VEC1 <key-id>:<key-secret>'
```

Secrets are deliberately read from environment variables and `config.json` is ignored by Git.

Important settings:

- `Sync.DateField` defaults to `UpdatedAt`. This treats the assessment's last update as its completion date and catches assessments launched before the run date but completed on it. Set it to `CreatedAt` if "at the date" means assessments launched on that date.
- `Sync.TimeZoneId` defines the calendar day. The script freezes that day's UTC boundaries at startup. Use a valid time-zone ID for the host OS; omit it to use the host's local zone.
- `Cymulate.LaunchedAssessmentsPath` defaults to the requested `/launched-assessments` route and is also the base for each `/<scenario.id>/findings` request. The supplied Cymulate OpenAPI document instead names this route `/v2/assessments/launched`; use that value when calling the documented Cymulate API directly.
- `Vectr.CampaignId` selects the existing VECTR campaign that receives the test cases.
- `Vectr.MutationMode` defaults to `MatchTemplateByName`. Use `WithoutTemplate` if templates must never be created.
- `SkipCertificateCheck` requires PowerShell 7 and should only be enabled for a VECTR or Cymulate host whose certificate you have independently verified.

## Run

Start with a dry run. It performs read-only validation and reports how many VECTR test cases would be created:

```powershell
.\Sync-CymulateToVectr.ps1 -ConfigPath .\config.json -DryRun -Verbose
```

For HTTP troubleshooting, add `-Debug`. This prints every request method and URI, sanitized request headers, JSON request bodies, complete response bodies, HTTP error bodies, and each assessment's local filtering decision. Authentication headers and tokens are replaced with `<redacted>`, but API response data may still contain sensitive assessment details. Capture and share debug logs accordingly.

```powershell
.\Sync-CymulateToVectr.ps1 `
    -ConfigPath .\config.json `
    -StartDate '2026-08-01' `
    -EndDate '2026-08-28' `
    -DryRun `
    -Verbose `
    -Debug
```

Run the import:

```powershell
.\Sync-CymulateToVectr.ps1 -ConfigPath .\config.json -Verbose
```

To backfill a specific local date:

```powershell
.\Sync-CymulateToVectr.ps1 -ConfigPath .\config.json -RunDate '2026-08-27'
```

To import an inclusive local date range:

```powershell
.\Sync-CymulateToVectr.ps1 `
    -ConfigPath .\config.json `
    -StartDate '2026-08-01' `
    -EndDate '2026-08-27' `
    -DryRun `
    -Verbose
```

`-StartDate` and `-EndDate` must be supplied together, and `-EndDate` cannot be earlier than `-StartDate`. Both are interpreted as calendar dates in `Sync.TimeZoneId`; the end date is inclusive. `-RunDate` remains available for a single-day import and cannot be combined with the range parameters.

## Mapping

For every date-filtered launched scenario, the script requests `<LaunchedAssessmentsPath>/<scenario.id>/findings`. It requires at least three findings and selects the first object whose `findingName` is exactly `SIEM Alert triggered`. A missing requirement stops the run with a clear error instead of creating a partially mapped test case.

| VECTR test-case field | Cymulate source |
| --- | --- |
| `attackStart` | `scenario.startedAt`, converted to Unix epoch milliseconds |
| `attackStop` | `scenario.endedAt`, converted to Unix epoch milliseconds |
| `name` | `scenario.name` |
| first and only `targets` item | `scenario.targets[0]`, split on whitespace, first non-empty token |
| `technique` (shown by VECTR as MITRE ID) | matched finding's `techniques[0].mitreID` |
| `phase` | matched finding's `tactics[0].mitreID` |

The matched finding's `detection` value is retained in VECTR metadata as `Cymulate SIEM Detection`. Outcome fields are deliberately not sent yet; they will be added after the outcome mapping is supplied. The launched-assessment payload must include `endedAt` even though that property is absent from the attached OpenAPI model; the script reports an error if it is missing.

The script records `scenario.id` as ordinary `Cymulate Scenario ID` metadata for traceability. It does not currently check for existing test cases or suppress duplicates. Re-running the same or an overlapping date range will create another set of VECTR test cases.

The Cymulate specification does not expose a dedicated completion timestamp. With `UpdatedAt`, the script must page through all completed assessments and filter locally because Cymulate's `fromDate`/`toDate` launched-assessment filter is tied to the launch/created date.
